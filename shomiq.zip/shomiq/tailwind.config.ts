import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1D1D1F",
        mist: "#F5F5F7",
        brand: { DEFAULT: "#2563EB", dark: "#1D4ED8" },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "sans-serif"],
      },
      boxShadow: { soft: "0 1px 2px rgba(0,0,0,.04), 0 8px 24px rgba(0,0,0,.05)" },
    },
  },
  plugins: [],
};
export default config;
