import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const services = [
  { name: "Web Development", slug: "web-development", order: 1,
    short: "Fast, accessible and well-crafted websites and web applications.",
    full: "We design and build modern websites and web applications.\n\n## What we can help with\n\n- Company websites and landing pages\n- Web applications and dashboards\n- Performance, accessibility and SEO",
    features: ["Responsive design", "Performance and SEO focus", "Content management", "Ongoing support"] },
  { name: "Software Development", slug: "software-development", order: 2,
    short: "Custom software built around the way your business works.",
    full: "We build custom software that is reliable, maintainable and designed around real needs.\n\n## What we can help with\n\n- Internal tools and business systems\n- APIs and integrations\n- Software modernisation",
    features: ["Requirement analysis", "Scalable architecture", "Testing and quality", "Maintenance"] },
  { name: "AI & Automation", slug: "ai-automation", order: 3,
    short: "Practical AI and automation that removes repetitive work.",
    full: "We apply AI and automation where it creates real value.\n\n## What we can help with\n\n- Workflow automation\n- AI-powered features and assistants\n- Data processing pipelines",
    features: ["Process automation", "AI integrations", "Custom workflows", "Responsible AI use"] },
  { name: "Mobile Application Development", slug: "mobile-app-development", order: 4,
    short: "Mobile apps that feel natural on Android and iOS.",
    full: "We create mobile applications focused on usability and performance.\n\n## What we can help with\n\n- Android and iOS apps\n- Cross-platform development\n- App store preparation",
    features: ["Android and iOS", "Intuitive UX", "API integration", "Release support"] },
  { name: "E-commerce Solutions", slug: "ecommerce-solutions", order: 5,
    short: "Online stores built for a smooth buying experience.",
    full: "We build online stores and the systems behind them.\n\n## What we can help with\n\n- Storefronts and catalogues\n- Payment and checkout integration\n- Order and inventory workflows",
    features: ["Storefront design", "Payment integration", "Catalogue management", "Analytics ready"] },
  { name: "Digital Solutions", slug: "digital-solutions", order: 6,
    short: "Digital products and services tailored to your goals.",
    full: "Not sure where to start? We help you turn an idea into a clear digital plan.\n\n## What we can help with\n\n- Product discovery and planning\n- UX and UI design\n- Digital transformation support",
    features: ["Discovery workshops", "UX and UI design", "Roadmapping", "Delivery support"] },
];

const team = [
  { fullName: "Shourya Maheshwari", designation: "Founder & CEO", order: 1 },
  { fullName: "Om Pathak", designation: "Co-Founder & CTO", order: 2 },
  { fullName: "Vanshit Upadhyay", designation: "Co-Founder & CMO", order: 3 },
];

const pages = [
  { slug: "about", title: "About Us",
    content: "## Who we are\n\nSHOMIQ TECHNOLOGIES is a technology company focused on creating meaningful digital products and solutions across software development, AI and digital services.\n\n## Our approach\n\nWe believe good technology should be simple, reliable and thoughtfully designed. Edit this section from the admin dashboard to tell your story in your own words.\n\n## Our vision\n\nTechnology. Designed for What's Next." },
  { slug: "privacy", title: "Privacy Policy",
    content: "Last updated: replace with date.\n\n## Information we collect\n\nWhen you use our contact form we collect your name, email address, optional phone number and company, and the message you send us.\n\n## How we use it\n\nWe use this information only to respond to your enquiry and to manage our business relationship with you.\n\n## Storage and security\n\nEnquiries are stored in a secured database and are accessible only to authorised staff.\n\n## Sharing\n\nWe do not sell your personal information. We may use trusted service providers (for example email delivery) strictly to operate this website.\n\n## Your rights\n\nYou can ask us to access, correct or delete your information by contacting us.\n\n## Contact\n\nUse the contact page for any privacy-related questions." },
  { slug: "terms", title: "Terms & Conditions",
    content: "Last updated: replace with date.\n\n## Use of this website\n\nBy using this website you agree to these terms. Please do not misuse the site or attempt to disrupt its operation.\n\n## Intellectual property\n\nThe content, branding and design of this website belong to SHOMIQ TECHNOLOGIES unless stated otherwise.\n\n## No warranty\n\nThe information on this website is provided for general purposes and may change without notice.\n\n## Limitation of liability\n\nTo the extent permitted by law, SHOMIQ TECHNOLOGIES is not liable for losses arising from use of this website.\n\n## Changes\n\nWe may update these terms from time to time.\n\n## Contact\n\nUse the contact page for questions about these terms." },
];

async function main() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 12) {
    throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD (min 12 characters) in .env before seeding.");
  }
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { email },
    update: { passwordHash },
    create: { email, name: process.env.ADMIN_NAME || "Admin", passwordHash },
  });

  for (const s of services) {
    await prisma.service.upsert({
      where: { slug: s.slug },
      update: {},
      create: { name: s.name, slug: s.slug, shortDescription: s.short, fullDescription: s.full, features: s.features, displayOrder: s.order, status: "PUBLISHED" },
    });
  }

  for (const t of team) {
    const exists = await prisma.teamMember.findFirst({ where: { fullName: t.fullName } });
    if (!exists) {
      await prisma.teamMember.create({
        data: { fullName: t.fullName, designation: t.designation, bio: "Biography coming soon. Edit this profile from the admin dashboard.", displayOrder: t.order, skills: [] },
      });
    }
  }

  for (const p of pages) {
    await prisma.page.upsert({ where: { slug: p.slug }, update: {}, create: { slug: p.slug, title: p.title, content: p.content } });
  }

  await prisma.project.upsert({
    where: { slug: "sample-project" },
    update: {},
    create: {
      name: "Sample Project (Placeholder)", slug: "sample-project", category: "Web Development",
      shortDescription: "A placeholder project. Replace or delete it from the admin dashboard.",
      detailedDescription: "This is a draft placeholder so you can see how projects are structured.\n\n## Overview\n\nEdit this text, add images and publish when ready.",
      technologies: ["Next.js", "PostgreSQL"], status: "DRAFT",
    },
  });

  console.log(`Seed complete. Admin login: ${email}`);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
