import { z } from "zod";

const emptyToNull = (v: string | undefined) => (v && v.trim() ? v.trim() : null);
const list = (v: string) => v.split(/[\n,]/).map((s) => s.trim()).filter(Boolean);
const lines = (v: string) => v.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);

const optText = (max: number) => z.string().trim().max(max).optional().transform(emptyToNull);
const optUrl = z
  .string()
  .trim()
  .max(500)
  .optional()
  .refine((v) => !v || /^https?:\/\//i.test(v), "Must start with http:// or https://")
  .transform(emptyToNull);
const slug = z
  .string()
  .trim()
  .toLowerCase()
  .min(2, "Slug is required")
  .max(120)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers and hyphens only");
const status = z.enum(["DRAFT", "PUBLISHED"]);
const order = z.coerce.number().int().min(0).max(9999).default(0);

export const enquirySchema = z.object({
  name: z.string().trim().min(2, "Please enter your name").max(100),
  email: z.string().trim().email("Please enter a valid email").max(200),
  phone: z
    .string()
    .trim()
    .max(25)
    .optional()
    .refine((v) => !v || /^[0-9+\-()\s.]{7,25}$/.test(v), "Please enter a valid phone number")
    .transform(emptyToNull),
  company: optText(150),
  subject: z.string().trim().min(3, "Please add a subject").max(150),
  message: z.string().trim().min(10, "Message should be at least 10 characters").max(5000),
});

export const serviceSchema = z.object({
  name: z.string().trim().min(2).max(120),
  slug,
  shortDescription: z.string().trim().min(5, "Short description is required").max(300),
  fullDescription: z.string().trim().min(5, "Full description is required").max(20000),
  coverImage: optUrl,
  features: z.string().default("").transform(lines),
  displayOrder: order,
  seoTitle: optText(70),
  seoDescription: optText(170),
  status,
});

export const projectSchema = z.object({
  name: z.string().trim().min(2).max(150),
  slug,
  category: z.string().trim().min(2, "Category is required").max(80),
  shortDescription: z.string().trim().min(5).max(300),
  detailedDescription: z.string().trim().min(5).max(30000),
  thumbnail: optUrl,
  images: z.string().default("").transform(lines),
  technologies: z.string().default("").transform(list),
  projectUrl: optUrl,
  githubUrl: optUrl,
  completionDate: z
    .string()
    .optional()
    .refine((v) => !v || !isNaN(Date.parse(v)), "Invalid date")
    .transform((v) => (v ? new Date(v) : null)),
  featured: z.boolean().default(false),
  seoTitle: optText(70),
  seoDescription: optText(170),
  status,
});

export const teamSchema = z.object({
  fullName: z.string().trim().min(2).max(120),
  designation: z.string().trim().min(2).max(120),
  bio: z.string().trim().min(2).max(5000),
  photo: optUrl,
  skills: z.string().default("").transform(list),
  linkedinUrl: optUrl,
  twitterUrl: optUrl,
  githubUrl: optUrl,
  instagramUrl: optUrl,
  websiteUrl: optUrl,
  displayOrder: order,
  status,
});

export const pageSchema = z.object({
  title: z.string().trim().min(2).max(150),
  content: z.string().trim().min(1, "Content is required").max(60000),
  status,
  seoTitle: optText(70),
  seoDescription: optText(170),
});

export const seoSchema = z.object({
  path: z.string(),
  title: optText(70),
  description: optText(170),
  ogImage: optUrl,
  noIndex: z.boolean().default(false),
});

export const profileSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().toLowerCase().email().max(200),
});

export const passwordSchema = z
  .object({
    current: z.string().min(1, "Enter your current password"),
    next: z
      .string()
      .min(12, "Use at least 12 characters")
      .max(200)
      .regex(/[A-Za-z]/, "Include at least one letter")
      .regex(/[0-9]/, "Include at least one number"),
    confirm: z.string(),
  })
  .refine((d) => d.next === d.confirm, { message: "Passwords do not match", path: ["confirm"] });

export const SEO_PATHS = ["/", "/about", "/services", "/work", "/team", "/contact", "/privacy", "/terms"] as const;
