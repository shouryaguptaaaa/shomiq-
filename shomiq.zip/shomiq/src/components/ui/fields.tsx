import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Field({ label, help, children, className }: { label: string; help?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="label">{label}</span>
      {children}
      {help && <span className="mt-1 block text-xs text-ink/55">{help}</span>}
    </label>
  );
}
export const Input = ({ className, ...p }: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cn("input", className)} />;
export const Textarea = ({ className, ...p }: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cn("input", className)} />;
export const Select = ({ className, ...p }: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cn("input", className)} />;

export function StatusSelect({ defaultValue = "PUBLISHED" }: { defaultValue?: string }) {
  return (
    <Field label="Status">
      <Select name="status" defaultValue={defaultValue}>
        <option value="PUBLISHED">Published</option>
        <option value="DRAFT">Draft (hidden)</option>
      </Select>
    </Field>
  );
}

export function Badge({ value }: { value: string }) {
  const map: Record<string, string> = {
    PUBLISHED: "bg-green-50 text-green-700",
    DRAFT: "bg-neutral-100 text-neutral-600",
    NEW: "bg-blue-50 text-blue-700",
    IN_PROGRESS: "bg-amber-50 text-amber-700",
    RESOLVED: "bg-green-50 text-green-700",
  };
  return <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium", map[value] ?? "bg-neutral-100")}>{value.replace("_", " ").toLowerCase()}</span>;
}
