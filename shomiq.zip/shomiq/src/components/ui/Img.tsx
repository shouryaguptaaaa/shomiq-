import Image from "next/image";
import { cn } from "@/lib/utils";

/** Fills its (relative, sized) parent. Falls back to a soft placeholder when there is no image. */
export function Img({ src, alt, className, sizes, priority }: { src?: string | null; alt: string; className?: string; sizes?: string; priority?: boolean }) {
  if (!src) return <div aria-hidden className={cn("absolute inset-0 bg-mist", className)} />;
  const optimised = src.startsWith("https://res.cloudinary.com/") || src.startsWith("/");
  if (!optimised) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt={alt} loading={priority ? "eager" : "lazy"} className={cn("absolute inset-0 h-full w-full object-cover", className)} />;
  }
  return <Image src={src} alt={alt} fill priority={priority} sizes={sizes ?? "(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"} className={cn("object-cover", className)} />;
}
