/** Safe, minimal renderer: paragraphs, "## " headings and "- " lists. No raw HTML is ever injected. */
export function RichText({ text }: { text: string }) {
  const blocks = text.split(/\n{2,}/).filter(Boolean);
  return (
    <div className="space-y-5 text-[17px] leading-relaxed text-ink/80">
      {blocks.map((b, i) => {
        if (b.startsWith("## ")) return <h2 key={i} className="pt-6 text-2xl font-semibold tracking-tight text-ink">{b.slice(3)}</h2>;
        const ls = b.split("\n");
        if (ls.every((l) => l.startsWith("- "))) {
          return <ul key={i} className="list-disc space-y-2 pl-6">{ls.map((l, j) => <li key={j}>{l.slice(2)}</li>)}</ul>;
        }
        return <p key={i} className="whitespace-pre-line">{b}</p>;
      })}
    </div>
  );
}
