"use client";

import { useActionState, useEffect, useRef, startTransition, type ReactNode } from "react";
import { Loader2 } from "lucide-react";
import type { ActionState } from "@/lib/action-utils";
import { cn } from "@/lib/utils";

type Props = {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  children: ReactNode;
  submitLabel?: string;
  className?: string;
  resetOnSuccess?: boolean;
  buttonClassName?: string;
};

export function ActionForm({ action, children, submitLabel = "Save", className, resetOnSuccess, buttonClassName }: Props) {
  const [state, run, pending] = useActionState(action, {} as ActionState);
  const ref = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.ok && resetOnSuccess) ref.current?.reset();
  }, [state, resetOnSuccess]);

  return (
    <form
      ref={ref}
      className={className}
      onSubmit={(e) => {
        e.preventDefault(); // keeps typed values when validation fails
        const fd = new FormData(e.currentTarget);
        startTransition(() => run(fd));
      }}
    >
      {children}
      {state.error && (
        <div role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          <p className="font-medium">{state.error}</p>
          {state.fieldErrors && (
            <ul className="mt-1 list-disc pl-5">
              {Object.entries(state.fieldErrors).map(([k, v]) => (
                <li key={k}>
                  <span className="font-medium">{k}:</span> {v?.join(", ")}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
      {state.ok && state.message && (
        <div role="status" className="rounded-xl bg-green-50 px-4 py-3 text-sm text-green-800">{state.message}</div>
      )}
      <button type="submit" disabled={pending} className={cn("btn-primary", buttonClassName)}>
        {pending && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
        {pending ? "Please wait…" : submitLabel}
      </button>
    </form>
  );
}
