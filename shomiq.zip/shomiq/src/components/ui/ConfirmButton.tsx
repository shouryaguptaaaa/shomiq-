"use client";

import type { ReactNode } from "react";

export function ConfirmButton({ action, message, children, className = "btn-danger" }: { action: () => Promise<void>; message: string; children: ReactNode; className?: string }) {
  return (
    <form action={action} onSubmit={(e) => { if (!confirm(message)) e.preventDefault(); }}>
      <button type="submit" className={className}>{children}</button>
    </form>
  );
}
