export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" aria-hidden="true">
      <rect width="28" height="28" rx="8" fill="#1D1D1F" />
      <path d="M19 10c0-1.7-2-2.8-5-2.8S9 8.4 9 10.3s2 2.9 5 3.7 5 1.8 5 3.8-2 3.1-5 3.1-5-1.2-5-2.8" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
      <circle cx="20.5" cy="7.5" r="2" fill="#2563EB" />
    </svg>
  );
}

export function Logo({ name = "SHOMIQ TECHNOLOGIES" }: { name?: string }) {
  const [first, ...rest] = name.split(" ");
  return (
    <span className="inline-flex items-center gap-2.5" aria-label={name}>
      <LogoMark />
      <span className="flex flex-col leading-none">
        <span className="text-[15px] font-semibold tracking-[0.12em]">{first}</span>
        {rest.length > 0 && <span className="mt-0.5 text-[8px] font-medium tracking-[0.32em] text-ink/55">{rest.join(" ")}</span>}
      </span>
    </span>
  );
}
