"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Check, Copy, Loader2, Upload } from "lucide-react";

export function UploadButton() {
  const router = useRouter();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function go(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    setErr(null);
    for (const f of Array.from(files)) {
      const fd = new FormData();
      fd.append("file", f);
      const r = await fetch("/api/upload", { method: "POST", body: fd });
      if (!r.ok) {
        const j = await r.json().catch(() => ({}));
        setErr(`${f.name}: ${j.error || "Upload failed"}`);
      }
    }
    setBusy(false);
    if (ref.current) ref.current.value = "";
    router.refresh();
  }

  return (
    <div>
      <button type="button" disabled={busy} onClick={() => ref.current?.click()} className="btn-primary btn-sm">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}{busy ? "Uploading…" : "Upload images"}
      </button>
      <input ref={ref} type="file" hidden multiple accept="image/jpeg,image/png,image/webp,image/gif,image/avif" onChange={(e) => go(e.target.files)} />
      {err && <p role="alert" className="mt-2 text-sm text-red-600">{err}</p>}
    </div>
  );
}

export function CopyButton({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className="btn-secondary btn-sm" onClick={async () => { await navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); }}>
      {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}{done ? "Copied" : "Copy URL"}
    </button>
  );
}
