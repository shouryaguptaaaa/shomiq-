import Link from "next/link";
import type { ReactNode } from "react";
import { Plus } from "lucide-react";

export function AdminHeader({ title, text, newHref, newLabel }: { title: string; text?: string; newHref?: string; newLabel?: string }) {
  return (
    <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h1>
        {text && <p className="mt-1 text-sm text-ink/60">{text}</p>}
      </div>
      {newHref && <Link href={newHref} className="btn-primary btn-sm"><Plus className="h-4 w-4" />{newLabel ?? "New"}</Link>}
    </div>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`card p-5 sm:p-7 ${className}`}>{children}</div>;
}

export function Empty({ text }: { text: string }) {
  return <p className="rounded-2xl bg-white px-6 py-12 text-center text-sm text-ink/60">{text}</p>;
}
