"use client";

import { useRef, useState } from "react";
import { ImagePlus, Library, Loader2, X } from "lucide-react";

type Item = { id: string; url: string; alt: string | null };

export function ImageField({ name, label, defaultValue, multiple = false, help }: { name: string; label: string; defaultValue?: string | string[] | null; multiple?: boolean; help?: string }) {
  const initial = (Array.isArray(defaultValue) ? defaultValue : (defaultValue ?? "").split("\n")).map((s) => s.trim()).filter(Boolean);
  const [urls, setUrls] = useState<string[]>(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [lib, setLib] = useState<Item[] | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const add = (u: string) => setUrls((p) => (multiple ? (p.includes(u) ? p : [...p, u]) : [u]));

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    setErr(null);
    try {
      for (const f of Array.from(files)) {
        const fd = new FormData();
        fd.append("file", f);
        const r = await fetch("/api/upload", { method: "POST", body: fd });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.error || "Upload failed");
        add(j.url);
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function openLibrary() {
    setOpen(true);
    if (!lib) {
      const r = await fetch("/api/media");
      setLib(r.ok ? (await r.json()).items : []);
    }
  }

  return (
    <div>
      <span className="label">{label}</span>
      <input type="hidden" name={name} value={multiple ? urls.join("\n") : urls[0] ?? ""} />
      {urls.length > 0 && (
        <ul className="mb-3 grid grid-cols-3 gap-3 sm:grid-cols-4">
          {urls.map((u) => (
            <li key={u} className="group relative aspect-square overflow-hidden rounded-xl bg-mist">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={u} alt="" className="h-full w-full object-cover" />
              <button type="button" aria-label="Remove image" onClick={() => setUrls((p) => p.filter((x) => x !== u))} className="absolute right-1.5 top-1.5 rounded-full bg-white/90 p-1 shadow">
                <X className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="flex flex-wrap gap-2">
        <button type="button" disabled={busy} onClick={() => fileRef.current?.click()} className="btn-secondary btn-sm">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}{busy ? "Uploading…" : "Upload"}
        </button>
        <button type="button" onClick={openLibrary} className="btn-secondary btn-sm"><Library className="h-4 w-4" />Media library</button>
        <input ref={fileRef} type="file" hidden multiple={multiple} accept="image/jpeg,image/png,image/webp,image/gif,image/avif" onChange={(e) => upload(e.target.files)} />
      </div>
      {help && <p className="mt-1 text-xs text-ink/55">{help}</p>}
      {err && <p role="alert" className="mt-2 text-sm text-red-600">{err}</p>}

      {open && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label="Media library">
          <div className="max-h-[85vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl bg-white p-5 sm:rounded-3xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-semibold">Choose an image</h2>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="rounded-full p-2 hover:bg-mist"><X className="h-4 w-4" /></button>
            </div>
            {lib === null ? <p className="py-10 text-center text-sm text-ink/60">Loading…</p> : lib.length === 0 ? (
              <p className="py-10 text-center text-sm text-ink/60">No images yet. Upload one first.</p>
            ) : (
              <ul className="grid grid-cols-3 gap-3 sm:grid-cols-4">
                {lib.map((m) => (
                  <li key={m.id}>
                    <button type="button" onClick={() => { add(m.url); if (!multiple) setOpen(false); }} className="aspect-square w-full overflow-hidden rounded-xl bg-mist ring-brand hover:ring-2">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={m.url} alt={m.alt ?? ""} className="h-full w-full object-cover" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {multiple && <button type="button" onClick={() => setOpen(false)} className="btn-primary btn-sm mt-5">Done</button>}
          </div>
        </div>
      )}
    </div>
  );
}
