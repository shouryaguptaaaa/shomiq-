"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Briefcase, ExternalLink, FileText, FolderKanban, Home, Image as ImageIcon, Inbox, LayoutDashboard, LogOut, Menu, Search, Settings, ShieldCheck, UserCircle, Users, X } from "lucide-react";
import { LogoMark } from "@/components/ui/Logo";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/admin", label: "Dashboard", Icon: LayoutDashboard },
  { href: "/admin/pages", label: "Pages", Icon: FileText },
  { href: "/admin/homepage", label: "Homepage", Icon: Home },
  { href: "/admin/services", label: "Services", Icon: Briefcase },
  { href: "/admin/projects", label: "Projects", Icon: FolderKanban },
  { href: "/admin/team", label: "Team", Icon: Users },
  { href: "/admin/enquiries", label: "Enquiries", Icon: Inbox },
  { href: "/admin/media", label: "Media", Icon: ImageIcon },
  { href: "/admin/seo", label: "SEO", Icon: Search },
  { href: "/admin/settings", label: "Settings", Icon: Settings },
  { href: "/admin/profile", label: "Profile", Icon: UserCircle },
  { href: "/admin/security", label: "Security", Icon: ShieldCheck },
];

export function AdminShell({ user, logout, children }: { user: { name: string; email: string }; logout: () => Promise<void>; children: ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const active = (h: string) => (h === "/admin" ? pathname === "/admin" : pathname.startsWith(h));

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5"><LogoMark /><span className="text-sm font-semibold tracking-wider">SHOMIQ Admin</span></div>
      <nav aria-label="Admin" className="flex-1 space-y-0.5 overflow-y-auto px-3">
        {NAV.map(({ href, label, Icon }) => (
          <Link key={href} href={href} onClick={() => setOpen(false)} className={cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors", active(href) ? "bg-white font-medium text-brand shadow-soft" : "text-ink/70 hover:bg-white/70")}>
            <Icon className="h-4 w-4" aria-hidden />{label}
          </Link>
        ))}
        <a href="/" target="_blank" rel="noopener noreferrer" className="mt-2 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-ink/70 hover:bg-white/70"><ExternalLink className="h-4 w-4" aria-hidden />View website</a>
      </nav>
      <div className="border-t border-black/5 p-4">
        <p className="truncate text-sm font-medium">{user.name}</p>
        <p className="truncate text-xs text-ink/55">{user.email}</p>
        <form action={logout}><button className="mt-3 flex items-center gap-2 text-sm text-ink/70 hover:text-red-600"><LogOut className="h-4 w-4" aria-hidden />Sign out</button></form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-mist lg:grid lg:grid-cols-[250px_1fr]">
      <aside className="sticky top-0 hidden h-screen border-r border-black/5 bg-mist lg:block">{sidebar}</aside>
      <div className="flex items-center justify-between border-b border-black/5 bg-white px-4 py-3 lg:hidden">
        <span className="flex items-center gap-2"><LogoMark size={24} /><span className="text-sm font-semibold">Admin</span></span>
        <button type="button" onClick={() => setOpen(true)} aria-label="Open menu" className="rounded-full p-2"><Menu className="h-5 w-5" /></button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/30" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 bg-mist shadow-xl">
            <button type="button" onClick={() => setOpen(false)} aria-label="Close menu" className="absolute right-3 top-3 rounded-full p-2"><X className="h-5 w-5" /></button>
            {sidebar}
          </div>
        </div>
      )}
      <main className="min-w-0 p-4 sm:p-8">{children}</main>
    </div>
  );
}
