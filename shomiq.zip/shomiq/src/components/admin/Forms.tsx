import type { Project, Service, TeamMember, Page } from "@prisma/client";
import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input, StatusSelect, Textarea } from "@/components/ui/fields";
import { ImageField } from "./ImageField";
import { Panel } from "./bits";
import { saveService } from "@/actions/services";
import { saveProject } from "@/actions/projects";
import { saveTeamMember } from "@/actions/team";
import { savePage } from "@/actions/content";

const Seo = ({ t, d }: { t?: string | null; d?: string | null }) => (
  <Panel className="space-y-5">
    <h2 className="text-lg font-semibold">SEO</h2>
    <Field label="SEO title" help="Up to 70 characters. Leave empty to use the name."><Input name="seoTitle" defaultValue={t ?? ""} maxLength={70} /></Field>
    <Field label="SEO description" help="Up to 170 characters."><Textarea name="seoDescription" defaultValue={d ?? ""} rows={2} maxLength={170} /></Field>
  </Panel>
);

export function ServiceForm({ service }: { service?: Service }) {
  return (
    <ActionForm action={saveService} submitLabel={service ? "Save changes" : "Create service"} className="max-w-3xl space-y-6">
      {service && <input type="hidden" name="id" value={service.id} />}
      <Panel className="space-y-5">
        <Field label="Name *"><Input name="name" required defaultValue={service?.name} maxLength={120} /></Field>
        <Field label="Slug" help="URL part, e.g. web-development. Leave empty to generate from the name."><Input name="slug" defaultValue={service?.slug} maxLength={120} /></Field>
        <Field label="Short description *"><Textarea name="shortDescription" required rows={2} defaultValue={service?.shortDescription} maxLength={300} /></Field>
        <Field label="Full description *" help='Blank line = new paragraph. "## Heading" for headings. "- item" for bullet lists.'><Textarea name="fullDescription" required rows={10} defaultValue={service?.fullDescription} /></Field>
        <ImageField name="coverImage" label="Cover image" defaultValue={service?.coverImage} />
        <Field label="Features" help="One per line."><Textarea name="features" rows={5} defaultValue={service?.features.join("\n")} /></Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Display order" help="Lower numbers appear first."><Input name="displayOrder" type="number" min={0} defaultValue={service?.displayOrder ?? 0} /></Field>
          <StatusSelect defaultValue={service?.status} />
        </div>
      </Panel>
      <Seo t={service?.seoTitle} d={service?.seoDescription} />
    </ActionForm>
  );
}

export function ProjectForm({ project }: { project?: Project }) {
  return (
    <ActionForm action={saveProject} submitLabel={project ? "Save changes" : "Create project"} className="max-w-3xl space-y-6">
      {project && <input type="hidden" name="id" value={project.id} />}
      <Panel className="space-y-5">
        <Field label="Project name *"><Input name="name" required defaultValue={project?.name} maxLength={150} /></Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Slug" help="Leave empty to generate."><Input name="slug" defaultValue={project?.slug} maxLength={120} /></Field>
          <Field label="Category *"><Input name="category" required defaultValue={project?.category} maxLength={80} /></Field>
        </div>
        <Field label="Short description *"><Textarea name="shortDescription" required rows={2} defaultValue={project?.shortDescription} maxLength={300} /></Field>
        <Field label="Detailed description *" help='Blank line = new paragraph. "## Heading", "- item" supported.'><Textarea name="detailedDescription" required rows={10} defaultValue={project?.detailedDescription} /></Field>
        <ImageField name="thumbnail" label="Thumbnail" defaultValue={project?.thumbnail} />
        <ImageField name="images" label="Project gallery" multiple defaultValue={project?.images} />
        <Field label="Technologies used" help="Comma or line separated."><Input name="technologies" defaultValue={project?.technologies.join(", ")} /></Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Project URL"><Input name="projectUrl" type="url" placeholder="https://" defaultValue={project?.projectUrl ?? ""} /></Field>
          <Field label="GitHub URL"><Input name="githubUrl" type="url" placeholder="https://github.com/…" defaultValue={project?.githubUrl ?? ""} /></Field>
          <Field label="Completion date"><Input name="completionDate" type="date" defaultValue={project?.completionDate?.toISOString().slice(0, 10)} /></Field>
          <StatusSelect defaultValue={project?.status ?? "DRAFT"} />
        </div>
        <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="featured" defaultChecked={project?.featured} className="h-4 w-4 accent-brand" />Featured on the homepage</label>
      </Panel>
      <Seo t={project?.seoTitle} d={project?.seoDescription} />
    </ActionForm>
  );
}

export function TeamForm({ member }: { member?: TeamMember }) {
  return (
    <ActionForm action={saveTeamMember} submitLabel={member ? "Save changes" : "Add member"} className="max-w-3xl space-y-6">
      {member && <input type="hidden" name="id" value={member.id} />}
      <Panel className="space-y-5">
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Full name *"><Input name="fullName" required defaultValue={member?.fullName} maxLength={120} /></Field>
          <Field label="Designation *"><Input name="designation" required defaultValue={member?.designation} maxLength={120} /></Field>
        </div>
        <Field label="Biography *"><Textarea name="bio" required rows={5} defaultValue={member?.bio} maxLength={5000} /></Field>
        <ImageField name="photo" label="Profile photograph" defaultValue={member?.photo} />
        <Field label="Skills / expertise" help="Comma or line separated."><Input name="skills" defaultValue={member?.skills.join(", ")} /></Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="LinkedIn URL"><Input name="linkedinUrl" type="url" defaultValue={member?.linkedinUrl ?? ""} /></Field>
          <Field label="X / Twitter URL"><Input name="twitterUrl" type="url" defaultValue={member?.twitterUrl ?? ""} /></Field>
          <Field label="GitHub URL"><Input name="githubUrl" type="url" defaultValue={member?.githubUrl ?? ""} /></Field>
          <Field label="Instagram URL"><Input name="instagramUrl" type="url" defaultValue={member?.instagramUrl ?? ""} /></Field>
          <Field label="Website URL"><Input name="websiteUrl" type="url" defaultValue={member?.websiteUrl ?? ""} /></Field>
          <Field label="Display order"><Input name="displayOrder" type="number" min={0} defaultValue={member?.displayOrder ?? 0} /></Field>
        </div>
        <StatusSelect defaultValue={member?.status} />
      </Panel>
    </ActionForm>
  );
}

export function PageForm({ page }: { page: Page }) {
  return (
    <ActionForm action={savePage} submitLabel="Save changes" className="max-w-3xl space-y-6">
      <input type="hidden" name="id" value={page.id} />
      <Panel className="space-y-5">
        <Field label="Title *"><Input name="title" required defaultValue={page.title} maxLength={150} /></Field>
        <Field label="Content *" help='Blank line = new paragraph. "## Heading" for headings. "- item" for bullet lists.'><Textarea name="content" required rows={16} defaultValue={page.content} /></Field>
        <StatusSelect defaultValue={page.status} />
      </Panel>
      <Seo t={page.seoTitle} d={page.seoDescription} />
    </ActionForm>
  );
}
