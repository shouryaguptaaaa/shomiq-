import { getSettings } from "@/services/content";
import { SETTING_GROUPS } from "@/lib/settings-defs";
import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input, Textarea } from "@/components/ui/fields";
import { ImageField } from "./ImageField";
import { Panel } from "./bits";
import { saveSettings } from "@/actions/content";

export async function SettingsForm({ groupIds }: { groupIds: string[] }) {
  const values = await getSettings();
  const groups = SETTING_GROUPS.filter((g) => groupIds.includes(g.id));
  return (
    <ActionForm action={saveSettings} submitLabel="Save changes" className="space-y-6">
      <input type="hidden" name="groups" value={groupIds.join(",")} />
      {groups.map((g) => (
        <Panel key={g.id} className="space-y-5">
          <div>
            <h2 className="text-lg font-semibold">{g.title}</h2>
            {g.description && <p className="text-sm text-ink/60">{g.description}</p>}
          </div>
          {g.fields.map((f) =>
            f.type === "image" ? (
              <ImageField key={f.key} name={f.key} label={f.label} defaultValue={values[f.key]} help={f.help} />
            ) : (
              <Field key={f.key} label={f.label} help={f.help}>
                {f.type === "text" ? (
                  <Input name={f.key} defaultValue={values[f.key]} maxLength={500} />
                ) : (
                  <Textarea name={f.key} defaultValue={values[f.key]} rows={f.type === "lines" ? 6 : 3} maxLength={5000} />
                )}
              </Field>
            )
          )}
        </Panel>
      ))}
    </ActionForm>
  );
}
