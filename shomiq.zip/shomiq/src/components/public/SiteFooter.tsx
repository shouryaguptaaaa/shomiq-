import Link from "next/link";
import { Github, Instagram, Linkedin, Twitter } from "lucide-react";
import { getSettings } from "@/services/content";
import { Logo } from "@/components/ui/Logo";
import { parsePairs, safeHref } from "@/lib/utils";

export async function SiteFooter() {
  const s = await getSettings();
  const links = parsePairs(s["nav.links"]).map((p) => ({ label: p.a, href: safeHref(p.b) }));
  const socials = [
    { href: s["social.linkedin"], label: "LinkedIn", Icon: Linkedin },
    { href: s["social.twitter"], label: "X / Twitter", Icon: Twitter },
    { href: s["social.github"], label: "GitHub", Icon: Github },
    { href: s["social.instagram"], label: "Instagram", Icon: Instagram },
  ].filter((x) => x.href);

  return (
    <footer className="mt-24 border-t border-black/5 bg-mist">
      <div className="container-x grid gap-12 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo name={s["company.name"]} />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-ink/65">{s["footer.text"]}</p>
          <address className="mt-5 space-y-1 text-sm not-italic text-ink/65">
            {s["company.email"] && <p><a className="hover:text-brand" href={`mailto:${s["company.email"]}`}>{s["company.email"]}</a></p>}
            {s["company.phone"] && <p><a className="hover:text-brand" href={`tel:${s["company.phone"].replace(/\s/g, "")}`}>{s["company.phone"]}</a></p>}
            {s["company.address"] && <p className="whitespace-pre-line">{s["company.address"]}</p>}
          </address>
          {socials.length > 0 && (
            <div className="mt-5 flex gap-3">
              {socials.map(({ href, label, Icon }) => (
                <a key={label} href={safeHref(href)} target="_blank" rel="noopener noreferrer" aria-label={label} className="rounded-full bg-white p-2 text-ink/70 shadow-soft transition-colors hover:text-brand">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          )}
        </div>
        <nav aria-label="Footer">
          <p className="text-sm font-semibold">Company</p>
          <ul className="mt-4 space-y-2.5 text-sm text-ink/65">
            {links.map((l) => <li key={l.href + l.label}><Link className="hover:text-brand" href={l.href}>{l.label}</Link></li>)}
          </ul>
        </nav>
        <nav aria-label="Legal">
          <p className="text-sm font-semibold">Legal</p>
          <ul className="mt-4 space-y-2.5 text-sm text-ink/65">
            <li><Link className="hover:text-brand" href="/privacy">Privacy Policy</Link></li>
            <li><Link className="hover:text-brand" href="/terms">Terms &amp; Conditions</Link></li>
          </ul>
        </nav>
      </div>
      <div className="border-t border-black/5">
        <p className="container-x py-5 text-xs text-ink/55">{s["footer.copyright"].replace("{year}", String(new Date().getFullYear()))}</p>
      </div>
    </footer>
  );
}
