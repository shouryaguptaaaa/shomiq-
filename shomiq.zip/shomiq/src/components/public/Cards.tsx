import Link from "next/link";
import { ArrowUpRight, Github, Globe, Instagram, Linkedin, Twitter } from "lucide-react";
import type { Project, Service, TeamMember } from "@prisma/client";
import { Img } from "@/components/ui/Img";
import { safeHref } from "@/lib/utils";

export function ServiceCard({ s }: { s: Pick<Service, "slug" | "name" | "shortDescription"> }) {
  return (
    <Link href={`/services/${s.slug}`} className="group flex h-full flex-col rounded-3xl bg-white p-8 transition-shadow hover:shadow-soft">
      <h3 className="text-xl font-semibold tracking-tight">{s.name}</h3>
      <p className="mt-3 flex-1 text-[15px] leading-relaxed text-ink/65">{s.shortDescription}</p>
      <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-brand">
        Learn more <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
      </span>
    </Link>
  );
}

export function ProjectCard({ p }: { p: Pick<Project, "slug" | "name" | "category" | "shortDescription" | "thumbnail"> }) {
  return (
    <Link href={`/work/${p.slug}`} className="group block">
      <div className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-mist">
        <Img src={p.thumbnail} alt={`${p.name} thumbnail`} className="transition-transform duration-500 group-hover:scale-[1.03]" />
      </div>
      <p className="mt-5 text-xs font-medium uppercase tracking-widest text-brand">{p.category}</p>
      <h3 className="mt-1.5 text-xl font-semibold tracking-tight">{p.name}</h3>
      <p className="mt-2 text-[15px] leading-relaxed text-ink/65">{p.shortDescription}</p>
    </Link>
  );
}

export function TeamCard({ m }: { m: TeamMember }) {
  const links = [
    { href: m.linkedinUrl, label: "LinkedIn", Icon: Linkedin },
    { href: m.twitterUrl, label: "X / Twitter", Icon: Twitter },
    { href: m.githubUrl, label: "GitHub", Icon: Github },
    { href: m.instagramUrl, label: "Instagram", Icon: Instagram },
    { href: m.websiteUrl, label: "Website", Icon: Globe },
  ].filter((l) => l.href);
  return (
    <article>
      <div className="relative aspect-square overflow-hidden rounded-3xl bg-mist">
        <Img src={m.photo} alt={`Portrait of ${m.fullName}`} sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" />
      </div>
      <h3 className="mt-5 text-xl font-semibold tracking-tight">{m.fullName}</h3>
      <p className="text-sm font-medium text-brand">{m.designation}</p>
      <p className="mt-3 text-[15px] leading-relaxed text-ink/65">{m.bio}</p>
      {m.skills.length > 0 && (
        <ul className="mt-4 flex flex-wrap gap-2">
          {m.skills.map((s) => <li key={s} className="rounded-full bg-mist px-3 py-1 text-xs text-ink/70">{s}</li>)}
        </ul>
      )}
      {links.length > 0 && (
        <div className="mt-4 flex gap-2">
          {links.map(({ href, label, Icon }) => (
            <a key={label} href={safeHref(href!)} target="_blank" rel="noopener noreferrer" aria-label={`${m.fullName} on ${label}`} className="rounded-full bg-mist p-2 text-ink/70 transition-colors hover:text-brand">
              <Icon className="h-4 w-4" />
            </a>
          ))}
        </div>
      )}
    </article>
  );
}

export function PageHero({ eyebrow, title, text }: { eyebrow?: string; title: string; text?: string | null }) {
  return (
    <section className="container-x pb-12 pt-16 sm:pb-16 sm:pt-24">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h1 className="mt-3 max-w-4xl text-4xl font-semibold tracking-tight sm:text-5xl lg:text-6xl">{title}</h1>
      {text && <p className="mt-5 max-w-2xl text-lg text-ink/70 sm:text-xl">{text}</p>}
    </section>
  );
}

export function EmptyState({ title, text }: { title: string; text: string }) {
  return (
    <div className="rounded-3xl bg-mist px-6 py-16 text-center">
      <p className="text-lg font-semibold">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-ink/65">{text}</p>
    </div>
  );
}
