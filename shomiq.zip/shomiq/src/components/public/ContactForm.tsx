"use client";

import { useEffect, useState } from "react";
import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input, Textarea } from "@/components/ui/fields";
import { submitEnquiry } from "@/actions/contact";

export function ContactForm({ defaultSubject = "" }: { defaultSubject?: string }) {
  const [ts, setTs] = useState("");
  useEffect(() => setTs(String(Date.now())), []);
  return (
    <ActionForm action={submitEnquiry} submitLabel="Send message" resetOnSuccess className="space-y-5" buttonClassName="w-full sm:w-auto">
      <input type="hidden" name="ts" value={ts} />
      {/* Honeypot: hidden from people, visible to bots */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>Website<input type="text" name="website" tabIndex={-1} autoComplete="off" /></label>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Name *"><Input name="name" required maxLength={100} autoComplete="name" /></Field>
        <Field label="Email *"><Input name="email" type="email" required maxLength={200} autoComplete="email" /></Field>
        <Field label="Phone (optional)"><Input name="phone" type="tel" maxLength={25} autoComplete="tel" /></Field>
        <Field label="Company (optional)"><Input name="company" maxLength={150} autoComplete="organization" /></Field>
      </div>
      <Field label="Subject *"><Input name="subject" required maxLength={150} defaultValue={defaultSubject} /></Field>
      <Field label="Message *"><Textarea name="message" required rows={6} minLength={10} maxLength={5000} /></Field>
    </ActionForm>
  );
}
