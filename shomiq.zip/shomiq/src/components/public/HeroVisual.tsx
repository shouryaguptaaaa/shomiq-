"use client";

import { motion, useReducedMotion } from "framer-motion";

const nodes: [number, number][] = [[220, 250], [420, 150], [600, 250], [780, 140], [980, 260], [600, 390]];

export function HeroVisual() {
  const reduce = useReducedMotion();
  const draw = (delay: number) => (reduce ? {} : { initial: { pathLength: 0, opacity: 0 }, animate: { pathLength: 1, opacity: 1 }, transition: { duration: 1.6, delay, ease: "easeOut" as const } });
  return (
    <div className="relative w-full overflow-hidden rounded-3xl border border-black/5 bg-mist">
      <svg viewBox="0 0 1200 500" role="img" aria-label="Abstract network of connected nodes representing technology" className="h-auto w-full">
        <defs>
          <radialGradient id="glow" cx="50%" cy="50%" r="55%">
            <stop offset="0%" stopColor="#2563EB" stopOpacity="0.10" />
            <stop offset="100%" stopColor="#2563EB" stopOpacity="0" />
          </radialGradient>
          <pattern id="dots" width="28" height="28" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1" fill="#1D1D1F" opacity="0.08" />
          </pattern>
        </defs>
        <rect width="1200" height="500" fill="url(#dots)" />
        <rect width="1200" height="500" fill="url(#glow)" />
        {[90, 150, 210, 270].map((r, i) => (
          <motion.circle key={r} cx="600" cy="250" r={r} fill="none" stroke="#2563EB" strokeOpacity={0.4 - i * 0.08} strokeWidth="1" {...draw(i * 0.2)} />
        ))}
        <motion.path d="M220 250 L420 150 L600 250 L780 140 L980 260" fill="none" stroke="#1D1D1F" strokeOpacity="0.35" strokeWidth="1.5" {...draw(0.4)} />
        <motion.path d="M600 250 L600 390" fill="none" stroke="#1D1D1F" strokeOpacity="0.35" strokeWidth="1.5" {...draw(0.8)} />
        {nodes.map(([x, y], i) => (
          <g key={i}>
            <circle cx={x} cy={y} r="14" fill="#fff" stroke="#2563EB" strokeOpacity="0.5" />
            <circle cx={x} cy={y} r="5" fill="#1D1D1F" />
          </g>
        ))}
        <circle cx="600" cy="250" r="38" fill="#1D1D1F" />
        <path d="M611 238c0-4-4-6-11-6s-11 2-11 6 4 6 11 8 11 3 11 7-4 6-11 6-11-3-11-6" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" transform="translate(0 -1)" />
      </svg>
    </div>
  );
}
