import { getSettings } from "@/services/content";
import { parsePairs, safeHref } from "@/lib/utils";
import { HeaderClient } from "./HeaderClient";

export async function SiteHeader() {
  const s = await getSettings();
  const links = parsePairs(s["nav.links"]).map((p) => ({ label: p.a, href: safeHref(p.b) }));
  return <HeaderClient name={s["company.name"]} links={links} />;
}
