"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { pageSchema, seoSchema, SEO_PATHS } from "@/validations";
import { dbFail, formObj, zodFail, type ActionState } from "@/lib/action-utils";
import { SETTING_GROUPS } from "@/lib/settings-defs";
import { logActivity } from "@/services/activity";

export async function savePage(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const raw = formObj(fd);
  const p = pageSchema.safeParse(raw);
  if (!p.success) return zodFail(p.error);
  const id = String(raw.id ?? "");
  try {
    const rec = await prisma.page.update({ where: { id }, data: p.data });
    await logActivity(admin.id, "updated", "Page", rec.id, rec.title);
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  redirect("/admin/pages");
}

export async function saveSettings(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const groupIds = String(fd.get("groups") ?? "").split(",");
  const fields = SETTING_GROUPS.filter((g) => groupIds.includes(g.id)).flatMap((g) => g.fields);
  const errors: Record<string, string[]> = {};
  const writes: { key: string; value: string }[] = [];

  for (const f of fields) {
    const value = String(fd.get(f.key) ?? "").replace(/\r\n/g, "\n").trim();
    const max = f.type === "textarea" || f.type === "lines" ? 5000 : 500;
    if (value.length > max) errors[f.label] = [`Maximum ${max} characters`];
    if (f.key.startsWith("social.") && value && !/^https?:\/\//i.test(value)) errors[f.label] = ["Must start with http:// or https://"];
    writes.push({ key: f.key, value });
  }
  if (Object.keys(errors).length) return { error: "Please correct the following and try again.", fieldErrors: errors };

  try {
    await prisma.$transaction(
      writes.map((w) => prisma.siteSetting.upsert({ where: { key: w.key }, update: { value: w.value }, create: w }))
    );
    await logActivity(admin.id, "updated", "Settings", undefined, groupIds.join(", "));
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  return { ok: true, message: "Saved. Changes are live on the website." };
}

export async function saveSeo(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const p = seoSchema.safeParse({ ...formObj(fd), noIndex: fd.get("noIndex") === "on" });
  if (!p.success) return zodFail(p.error);
  if (!(SEO_PATHS as readonly string[]).includes(p.data.path)) return { error: "Unknown page path." };
  try {
    await prisma.seoMetadata.upsert({ where: { path: p.data.path }, update: p.data, create: p.data });
    await logActivity(admin.id, "updated", "SEO", undefined, p.data.path);
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  return { ok: true, message: `SEO saved for ${p.data.path}` };
}
