"use server";

import { createHash } from "crypto";
import { headers } from "next/headers";
import { prisma } from "@/lib/db";
import { enquirySchema } from "@/validations";
import { sendEnquiryNotification } from "@/lib/email";
import { formObj, zodFail, type ActionState } from "@/lib/action-utils";

const THANKS = "Thank you. Your message has been sent and we'll get back to you soon.";

export async function submitEnquiry(_: ActionState, fd: FormData): Promise<ActionState> {
  // Honeypot: bots fill hidden fields. Pretend success.
  if (String(fd.get("website") ?? "") !== "") return { ok: true, message: THANKS };

  // Time check: humans take more than a couple of seconds.
  const ts = Number(fd.get("ts"));
  const age = Date.now() - ts;
  if (!ts || age < 2500 || age > 24 * 3600_000) return { error: "Please wait a moment and try again." };

  const parsed = enquirySchema.safeParse(formObj(fd));
  if (!parsed.success) return zodFail(parsed.error);

  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "unknown").split(",")[0].trim();
  const ipHash = createHash("sha256").update(ip + (process.env.AUTH_SECRET ?? "")).digest("hex");

  const recent = await prisma.enquiry.count({ where: { ipHash, createdAt: { gte: new Date(Date.now() - 3600_000) } } });
  if (recent >= 5) return { error: "You have sent several messages recently. Please try again later." };

  try {
    const enquiry = await prisma.enquiry.create({ data: { ...parsed.data, ipHash } });
    await sendEnquiryNotification(enquiry).catch((e) => console.error("email failed", e));
  } catch (e) {
    console.error(e);
    return { error: "We could not send your message right now. Please try again." };
  }
  return { ok: true, message: THANKS };
}
