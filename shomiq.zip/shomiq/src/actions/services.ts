"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { serviceSchema } from "@/validations";
import { dbFail, formObj, zodFail, type ActionState } from "@/lib/action-utils";
import { slugify } from "@/lib/utils";
import { logActivity } from "@/services/activity";

export async function saveService(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const raw = formObj(fd);
  if (!raw.slug) raw.slug = slugify(String(raw.name ?? ""));
  const p = serviceSchema.safeParse(raw);
  if (!p.success) return zodFail(p.error);
  const id = String(raw.id ?? "");
  try {
    const rec = id ? await prisma.service.update({ where: { id }, data: p.data }) : await prisma.service.create({ data: p.data });
    await logActivity(admin.id, id ? "updated" : "created", "Service", rec.id, rec.name);
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  redirect("/admin/services");
}

export async function deleteService(id: string) {
  const admin = await requireAdmin();
  const rec = await prisma.service.delete({ where: { id } });
  await logActivity(admin.id, "deleted", "Service", id, rec.name);
  revalidatePath("/", "layout");
}
