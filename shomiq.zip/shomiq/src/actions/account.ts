"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { passwordSchema, profileSchema } from "@/validations";
import { dbFail, formObj, zodFail, type ActionState } from "@/lib/action-utils";
import { logActivity } from "@/services/activity";

export async function updateProfile(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const p = profileSchema.safeParse(formObj(fd));
  if (!p.success) return zodFail(p.error);
  try {
    await prisma.user.update({ where: { id: admin.id }, data: p.data });
    await logActivity(admin.id, "updated", "Profile");
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/admin", "layout");
  return { ok: true, message: "Profile updated." };
}

export async function changePassword(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const p = passwordSchema.safeParse({ current: fd.get("current"), next: fd.get("next"), confirm: fd.get("confirm") });
  if (!p.success) return zodFail(p.error);
  const user = await prisma.user.findUnique({ where: { id: admin.id } });
  if (!user || !(await bcrypt.compare(p.data.current, user.passwordHash))) return { error: "Current password is incorrect." };
  await prisma.user.update({ where: { id: admin.id }, data: { passwordHash: await bcrypt.hash(p.data.next, 12) } });
  // Sign out every other session after a password change.
  await prisma.adminSession.updateMany({ where: { userId: admin.id, id: { not: admin.sid }, revokedAt: null }, data: { revokedAt: new Date() } });
  await logActivity(admin.id, "changed password", "Profile");
  return { ok: true, message: "Password changed. Other sessions were signed out." };
}

export async function revokeSession(id: string) {
  const admin = await requireAdmin();
  await prisma.adminSession.updateMany({ where: { id, userId: admin.id }, data: { revokedAt: new Date() } });
  await logActivity(admin.id, "revoked session", "Session", id);
  revalidatePath("/admin/security");
}

export async function revokeOtherSessions() {
  const admin = await requireAdmin();
  await prisma.adminSession.updateMany({ where: { userId: admin.id, id: { not: admin.sid }, revokedAt: null }, data: { revokedAt: new Date() } });
  await logActivity(admin.id, "revoked all other sessions", "Session");
  revalidatePath("/admin/security");
}
