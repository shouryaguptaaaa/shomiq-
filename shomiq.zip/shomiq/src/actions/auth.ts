"use server";

import { AuthError } from "next-auth";
import { auth, signIn, signOut } from "@/lib/auth";
import { prisma } from "@/lib/db";
import type { ActionState } from "@/lib/action-utils";

export async function loginAction(_: ActionState, fd: FormData): Promise<ActionState> {
  try {
    await signIn("credentials", {
      email: String(fd.get("email") ?? ""),
      password: String(fd.get("password") ?? ""),
      redirectTo: "/admin",
    });
  } catch (e) {
    if (e instanceof AuthError) return { error: "Invalid email or password, or too many attempts. Please try again later." };
    throw e; // redirect
  }
  return {};
}

export async function logoutAction() {
  const s = await auth();
  const sid = (s?.user as { sid?: string } | undefined)?.sid;
  if (sid) await prisma.adminSession.updateMany({ where: { id: sid }, data: { revokedAt: new Date() } });
  await signOut({ redirectTo: "/admin/login" });
}
