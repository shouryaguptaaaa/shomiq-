"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { teamSchema } from "@/validations";
import { dbFail, formObj, zodFail, type ActionState } from "@/lib/action-utils";
import { logActivity } from "@/services/activity";

export async function saveTeamMember(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const raw = formObj(fd);
  const p = teamSchema.safeParse(raw);
  if (!p.success) return zodFail(p.error);
  const id = String(raw.id ?? "");
  try {
    const rec = id ? await prisma.teamMember.update({ where: { id }, data: p.data }) : await prisma.teamMember.create({ data: p.data });
    await logActivity(admin.id, id ? "updated" : "created", "TeamMember", rec.id, rec.fullName);
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  redirect("/admin/team");
}

export async function deleteTeamMember(id: string) {
  const admin = await requireAdmin();
  const rec = await prisma.teamMember.delete({ where: { id } });
  await logActivity(admin.id, "deleted", "TeamMember", id, rec.fullName);
  revalidatePath("/", "layout");
}
