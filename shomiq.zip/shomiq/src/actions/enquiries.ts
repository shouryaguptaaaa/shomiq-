"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { logActivity } from "@/services/activity";

const STATUSES = ["NEW", "IN_PROGRESS", "RESOLVED"] as const;
type S = (typeof STATUSES)[number];

export async function setEnquiryStatus(id: string, status: S) {
  const admin = await requireAdmin();
  if (!STATUSES.includes(status)) return;
  const rec = await prisma.enquiry.update({ where: { id }, data: { status } });
  await logActivity(admin.id, `marked ${status.toLowerCase().replace("_", " ")}`, "Enquiry", id, rec.subject);
  revalidatePath("/admin", "layout");
}

export async function deleteEnquiry(id: string) {
  const admin = await requireAdmin();
  const rec = await prisma.enquiry.delete({ where: { id } });
  await logActivity(admin.id, "deleted", "Enquiry", id, rec.subject);
  revalidatePath("/admin", "layout");
}
