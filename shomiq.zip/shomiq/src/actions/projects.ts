"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { projectSchema } from "@/validations";
import { dbFail, formObj, zodFail, type ActionState } from "@/lib/action-utils";
import { slugify } from "@/lib/utils";
import { logActivity } from "@/services/activity";

export async function saveProject(_: ActionState, fd: FormData): Promise<ActionState> {
  const admin = await requireAdmin();
  const raw = formObj(fd);
  if (!raw.slug) raw.slug = slugify(String(raw.name ?? ""));
  const p = projectSchema.safeParse({ ...raw, featured: fd.get("featured") === "on" });
  if (!p.success) return zodFail(p.error);
  const id = String(raw.id ?? "");
  try {
    const rec = id ? await prisma.project.update({ where: { id }, data: p.data }) : await prisma.project.create({ data: p.data });
    await logActivity(admin.id, id ? "updated" : "created", "Project", rec.id, rec.name);
  } catch (e) {
    return dbFail(e);
  }
  revalidatePath("/", "layout");
  redirect("/admin/projects");
}

export async function deleteProject(id: string) {
  const admin = await requireAdmin();
  const rec = await prisma.project.delete({ where: { id } });
  await logActivity(admin.id, "deleted", "Project", id, rec.name);
  revalidatePath("/", "layout");
}
