"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { cloudinary, cloudinaryReady } from "@/lib/cloudinary";
import { logActivity } from "@/services/activity";

export async function deleteMedia(id: string) {
  const admin = await requireAdmin();
  const m = await prisma.media.findUnique({ where: { id } });
  if (!m) return;
  if (cloudinaryReady()) await cloudinary.uploader.destroy(m.publicId).catch((e) => console.error(e));
  await prisma.media.delete({ where: { id } });
  await logActivity(admin.id, "deleted", "Media", id, m.publicId);
  revalidatePath("/admin/media");
}
