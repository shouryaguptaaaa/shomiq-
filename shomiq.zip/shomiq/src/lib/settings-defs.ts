export type FieldDef = {
  key: string;
  label: string;
  type: "text" | "textarea" | "image" | "lines";
  default: string;
  help?: string;
};
export type GroupDef = { id: string; title: string; description?: string; fields: FieldDef[] };

export const SETTING_GROUPS: GroupDef[] = [
  {
    id: "home",
    title: "Homepage content",
    description: "Headings, text and buttons shown on the home page.",
    fields: [
      { key: "home.heroTitle", label: "Hero heading", type: "text", default: "Technology. Designed for What's Next." },
      { key: "home.heroSubtitle", label: "Hero supporting text", type: "textarea", default: "We transform ideas into meaningful digital experiences through technology, innovation and intelligent solutions." },
      { key: "home.heroPrimaryLabel", label: "Primary button label", type: "text", default: "Explore Our Work" },
      { key: "home.heroPrimaryHref", label: "Primary button link", type: "text", default: "/work" },
      { key: "home.heroSecondaryLabel", label: "Secondary button label", type: "text", default: "Let's Talk" },
      { key: "home.heroSecondaryHref", label: "Secondary button link", type: "text", default: "/contact" },
      { key: "home.heroImage", label: "Hero banner image (optional)", type: "image", default: "", help: "Leave empty to show the built-in abstract visual." },
      { key: "home.introTitle", label: "Introduction heading", type: "text", default: "A technology company built for what comes next." },
      { key: "home.introText", label: "Introduction text", type: "textarea", default: "SHOMIQ TECHNOLOGIES is a modern technology company focused on creating meaningful digital products and solutions across software development, AI and digital services." },
      { key: "home.servicesTitle", label: "Services heading", type: "text", default: "What we do" },
      { key: "home.servicesSubtitle", label: "Services subtitle", type: "text", default: "Technology services designed around your goals." },
      { key: "home.projectsTitle", label: "Featured projects heading", type: "text", default: "Selected work" },
      { key: "home.projectsSubtitle", label: "Featured projects subtitle", type: "text", default: "A look at what we have built." },
      { key: "home.whyTitle", label: "Why choose us heading", type: "text", default: "Why SHOMIQ" },
      { key: "home.whyItems", label: "Why choose us items", type: "lines", default: "Thoughtful design | Edit this text in the admin dashboard to describe your first differentiator.\nReliable engineering | Edit this text in the admin dashboard to describe your second differentiator.\nClear communication | Edit this text in the admin dashboard to describe your third differentiator.", help: "One item per line: Title | Description" },
      { key: "home.leadershipTitle", label: "Leadership heading", type: "text", default: "Leadership" },
      { key: "home.ctaTitle", label: "Contact CTA heading", type: "text", default: "Have an idea? Let's build something meaningful." },
      { key: "home.ctaLabel", label: "Contact CTA button label", type: "text", default: "Start a conversation" },
      { key: "home.ctaHref", label: "Contact CTA button link", type: "text", default: "/contact" },
    ],
  },
  {
    id: "company",
    title: "Company information",
    fields: [
      { key: "company.name", label: "Company name", type: "text", default: "SHOMIQ TECHNOLOGIES" },
      { key: "company.tagline", label: "Tagline", type: "text", default: "Technology. Designed for What's Next." },
      { key: "company.email", label: "Public email", type: "text", default: "" },
      { key: "company.phone", label: "Public phone", type: "text", default: "" },
      { key: "company.address", label: "Address", type: "textarea", default: "" },
    ],
  },
  {
    id: "footer",
    title: "Footer",
    fields: [
      { key: "footer.text", label: "Footer description", type: "textarea", default: "Building meaningful digital products and solutions." },
      { key: "footer.copyright", label: "Copyright text", type: "text", default: "© {year} SHOMIQ TECHNOLOGIES. All rights reserved.", help: "{year} is replaced automatically." },
    ],
  },
  {
    id: "social",
    title: "Social links",
    fields: [
      { key: "social.linkedin", label: "LinkedIn URL", type: "text", default: "" },
      { key: "social.twitter", label: "X / Twitter URL", type: "text", default: "" },
      { key: "social.github", label: "GitHub URL", type: "text", default: "" },
      { key: "social.instagram", label: "Instagram URL", type: "text", default: "" },
    ],
  },
  {
    id: "nav",
    title: "Navigation",
    fields: [
      { key: "nav.links", label: "Main navigation links", type: "lines", default: "Home | /\nAbout | /about\nServices | /services\nOur Work | /work\nTeam | /team\nContact | /contact", help: "One link per line: Label | /path" },
    ],
  },
];

export const ALL_FIELDS: FieldDef[] = SETTING_GROUPS.flatMap((g) => g.fields);
export const DEFAULTS: Record<string, string> = Object.fromEntries(ALL_FIELDS.map((f) => [f.key, f.default]));
