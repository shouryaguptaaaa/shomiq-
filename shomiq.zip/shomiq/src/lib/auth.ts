import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "./db";
import { rateLimit } from "./rate-limit";

const SESSION_HOURS = 8;

export const { handlers, auth, signIn, signOut } = NextAuth({
  session: { strategy: "jwt", maxAge: SESSION_HOURS * 3600 },
  pages: { signIn: "/admin/login" },
  trustHost: true,
  providers: [
    Credentials({
      credentials: { email: {}, password: {} },
      async authorize(raw, request) {
        const parsed = z.object({ email: z.string().email(), password: z.string().min(1).max(200) }).safeParse(raw);
        if (!parsed.success) return null;
        const email = parsed.data.email.toLowerCase();
        const ip = request?.headers?.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
        if (!rateLimit(`login:${ip}`, 20, 15 * 60_000).ok || !rateLimit(`login:${email}`, 8, 15 * 60_000).ok) return null;

        const user = await prisma.user.findUnique({ where: { email } });
        // Compare even when user is missing to keep timing similar.
        const hash = user?.passwordHash ?? "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvali";
        const ok = await bcrypt.compare(parsed.data.password, hash);
        if (!user || !ok) return null;

        const session = await prisma.adminSession.create({
          data: {
            userId: user.id,
            ip,
            userAgent: request?.headers?.get("user-agent")?.slice(0, 250) ?? null,
            expiresAt: new Date(Date.now() + SESSION_HOURS * 3600_000),
          },
        });
        await prisma.activityLog.create({ data: { userId: user.id, action: "login", entity: "Session", entityId: session.id } });
        return { id: user.id, email: user.email, name: user.name, sid: session.id } as never;
      },
    }),
  ],
  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.uid = user.id;
        token.sid = (user as unknown as { sid: string }).sid;
      }
      return token;
    },
    session({ session, token }) {
      Object.assign(session.user ?? {}, { id: token.uid, sid: token.sid });
      return session;
    },
  },
});
