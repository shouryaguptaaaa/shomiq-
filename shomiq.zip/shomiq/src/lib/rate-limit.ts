// Best-effort in-memory limiter (per server instance). Enquiries additionally use a database-backed limit.
const hits = new Map<string, { count: number; reset: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || h.reset < now) {
    hits.set(key, { count: 1, reset: now + windowMs });
    if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
    return { ok: true, remaining: limit - 1 };
  }
  h.count++;
  return { ok: h.count <= limit, remaining: Math.max(0, limit - h.count) };
}
