import type { Metadata } from "next";
import { prisma } from "./db";

export async function buildMetadata(o: { path: string; title?: string | null; description?: string | null; image?: string | null }): Promise<Metadata> {
  let ov = null;
  try {
    ov = await prisma.seoMetadata.findUnique({ where: { path: o.path } });
  } catch {}
  const title = ov?.title || o.title || undefined;
  const description = ov?.description || o.description || undefined;
  const image = ov?.ogImage || o.image || undefined;
  return {
    title,
    description,
    alternates: { canonical: o.path },
    robots: ov?.noIndex ? { index: false, follow: false } : undefined,
    openGraph: { title, description, url: o.path, type: "website", images: image ? [{ url: image }] : undefined },
    twitter: { card: image ? "summary_large_image" : "summary", title, description },
  };
}
