import { Resend } from "resend";
import type { Enquiry } from "@prisma/client";
import { escapeHtml } from "./utils";

export async function sendEnquiryNotification(e: Enquiry) {
  const key = process.env.RESEND_API_KEY;
  const to = process.env.NOTIFY_EMAIL;
  if (!key || !to) {
    console.warn("Resend not configured; skipping enquiry email.");
    return;
  }
  const resend = new Resend(key);
  const row = (k: string, v?: string | null) =>
    v ? `<tr><td style="padding:4px 12px 4px 0;color:#6e6e73">${k}</td><td style="padding:4px 0">${escapeHtml(v)}</td></tr>` : "";
  await resend.emails.send({
    from: process.env.EMAIL_FROM || "SHOMIQ TECHNOLOGIES <onboarding@resend.dev>",
    to,
    replyTo: e.email,
    subject: `New enquiry: ${e.subject}`.slice(0, 200),
    html: `<div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#1d1d1f">
      <h2 style="margin:0 0 12px">New website enquiry</h2>
      <table>${row("Name", e.name)}${row("Email", e.email)}${row("Phone", e.phone)}${row("Company", e.company)}${row("Subject", e.subject)}</table>
      <p style="white-space:pre-wrap;margin-top:16px">${escapeHtml(e.message)}</p>
    </div>`,
  });
}
