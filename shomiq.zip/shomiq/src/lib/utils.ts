import clsx, { type ClassValue } from "clsx";

export const cn = (...a: ClassValue[]) => clsx(a);

export const siteUrl = () => (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");

export function slugify(s: string) {
  return s.toLowerCase().trim().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export function fmtDate(d: Date | string | null | undefined) {
  if (!d) return "";
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" }).format(new Date(d));
}

export function fmtDateTime(d: Date | string | null | undefined) {
  if (!d) return "";
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(d));
}

export function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

/** Parse "A | B" per line into pairs. */
export function parsePairs(text: string) {
  return text
    .split(/\r?\n/)
    .map((l) => l.split("|"))
    .filter((p) => p[0]?.trim())
    .map((p) => ({ a: p[0].trim(), b: p.slice(1).join("|").trim() }));
}

/** Only allow safe link targets (blocks javascript: etc.). */
export function safeHref(h: string) {
  const v = (h || "").trim();
  if (v.startsWith("//")) return "/";
  if (/^(\/|#|https?:\/\/|mailto:|tel:)/i.test(v)) return v;
  return "/";
}

export const isExternal = (h: string) => /^https?:\/\//i.test(h);
