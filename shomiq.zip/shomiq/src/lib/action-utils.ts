import type { ZodError } from "zod";
import { Prisma } from "@prisma/client";

export type ActionState = {
  ok?: boolean;
  error?: string;
  message?: string;
  fieldErrors?: Record<string, string[] | undefined>;
};

export function zodFail(e: ZodError): ActionState {
  return { error: "Please correct the following and try again.", fieldErrors: e.flatten().fieldErrors };
}

export function dbFail(e: unknown): ActionState {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
    return { error: "That slug (or unique value) is already in use. Please choose another." };
  }
  console.error(e);
  return { error: "Something went wrong while saving. Please try again." };
}

export const formObj = (fd: FormData) => Object.fromEntries(fd.entries()) as Record<string, FormDataEntryValue>;
