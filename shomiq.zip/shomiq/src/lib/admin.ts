import { redirect } from "next/navigation";
import { auth } from "./auth";
import { prisma } from "./db";

export async function getAdminOrNull() {
  const session = await auth();
  const u = session?.user as { id?: string; sid?: string } | undefined;
  if (!u?.id || !u?.sid) return null;
  const s = await prisma.adminSession.findUnique({ where: { id: u.sid }, include: { user: true } });
  if (!s || s.revokedAt || s.expiresAt < new Date() || s.userId !== u.id) return null;
  return { id: s.user.id, sid: s.id, email: s.user.email, name: s.user.name };
}

export async function requireAdmin() {
  const a = await getAdminOrNull();
  if (!a) redirect("/admin/login");
  return a;
}
