import { NextResponse, type NextRequest } from "next/server";

// First line of defence only. Real session validation happens server-side in requireAdmin().
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const has = req.cookies.get("authjs.session-token") || req.cookies.get("__Secure-authjs.session-token");
    if (!has) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = { matcher: ["/admin/:path*"] };
