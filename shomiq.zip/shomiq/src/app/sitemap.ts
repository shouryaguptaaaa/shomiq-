import type { MetadataRoute } from "next";
import { prisma } from "@/lib/db";
import { siteUrl } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();
  const staticPaths = ["", "/about", "/services", "/work", "/team", "/contact", "/privacy", "/terms"];
  const entries: MetadataRoute.Sitemap = staticPaths.map((p) => ({ url: `${base}${p}`, changeFrequency: "monthly", priority: p === "" ? 1 : 0.7 }));
  try {
    const [services, projects] = await Promise.all([
      prisma.service.findMany({ where: { status: "PUBLISHED" }, select: { slug: true, updatedAt: true } }),
      prisma.project.findMany({ where: { status: "PUBLISHED" }, select: { slug: true, updatedAt: true } }),
    ]);
    services.forEach((s) => entries.push({ url: `${base}/services/${s.slug}`, lastModified: s.updatedAt, priority: 0.6 }));
    projects.forEach((p) => entries.push({ url: `${base}/work/${p.slug}`, lastModified: p.updatedAt, priority: 0.6 }));
  } catch (e) {
    console.error("sitemap db error", e);
  }
  return entries;
}
