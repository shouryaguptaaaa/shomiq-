import { getTeam } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { EmptyState, PageHero, TeamCard } from "@/components/public/Cards";

export async function generateMetadata() {
  return buildMetadata({ path: "/team", title: "Our Team", description: "Meet the people behind SHOMIQ TECHNOLOGIES." });
}

export default async function TeamPage() {
  const team = await getTeam();
  return (
    <>
      <PageHero eyebrow="Team" title="The people behind SHOMIQ." />
      <section className="container-x pb-16">
        {team.length === 0 ? <EmptyState title="Team coming soon" text="Team profiles will appear here." /> : (
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">{team.map((m) => <TeamCard key={m.id} m={m} />)}</div>
        )}
      </section>
    </>
  );
}
