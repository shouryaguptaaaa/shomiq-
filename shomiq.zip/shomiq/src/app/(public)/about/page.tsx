import { notFound } from "next/navigation";
import { getPage, getTeam } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { PageHero, TeamCard } from "@/components/public/Cards";
import { RichText } from "@/components/ui/RichText";
import { Reveal } from "@/components/public/Reveal";

export async function generateMetadata() {
  const p = await getPage("about");
  return buildMetadata({ path: "/about", title: p?.seoTitle || "About Us", description: p?.seoDescription });
}

export default async function AboutPage() {
  const [page, team] = await Promise.all([getPage("about"), getTeam()]);
  if (!page) notFound();
  return (
    <>
      <PageHero eyebrow="About" title={page.title} />
      <section className="container-x pb-16">
        <div className="max-w-3xl"><RichText text={page.content} /></div>
      </section>
      {team.length > 0 && (
        <section className="container-x pb-12">
          <Reveal><h2 className="text-3xl font-semibold tracking-tight">The people behind SHOMIQ</h2></Reveal>
          <div className="mt-10 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {team.map((m) => <TeamCard key={m.id} m={m} />)}
          </div>
        </section>
      )}
    </>
  );
}
