import Link from "next/link";
import { getProjectCategories, getProjects } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { cn } from "@/lib/utils";
import { EmptyState, PageHero, ProjectCard } from "@/components/public/Cards";

export async function generateMetadata() {
  return buildMetadata({ path: "/work", title: "Our Work", description: "Selected projects by SHOMIQ TECHNOLOGIES." });
}

export default async function WorkPage({ searchParams }: { searchParams: Promise<{ category?: string }> }) {
  const { category } = await searchParams;
  const [projects, categories] = await Promise.all([getProjects(category), getProjectCategories()]);
  const pill = (active: boolean) => cn("rounded-full px-4 py-2 text-sm transition-colors", active ? "bg-ink text-white" : "bg-mist text-ink/70 hover:text-ink");
  return (
    <>
      <PageHero eyebrow="Our Work" title="Things we have built." text="A selection of our projects." />
      <section className="container-x pb-16">
        {categories.length > 1 && (
          <nav aria-label="Project categories" className="mb-10 flex flex-wrap gap-2">
            <Link href="/work" className={pill(!category)}>All</Link>
            {categories.map((c) => <Link key={c} href={`/work?category=${encodeURIComponent(c)}`} className={pill(category === c)}>{c}</Link>)}
          </nav>
        )}
        {projects.length === 0 ? (
          <EmptyState title="No projects to show yet" text="Published projects will appear here." />
        ) : (
          <div className="grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">{projects.map((p) => <ProjectCard key={p.id} p={p} />)}</div>
        )}
      </section>
    </>
  );
}
