import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink, Github } from "lucide-react";
import { getProject } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { fmtDate, safeHref } from "@/lib/utils";
import { PageHero } from "@/components/public/Cards";
import { RichText } from "@/components/ui/RichText";
import { Img } from "@/components/ui/Img";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const p = await getProject(slug);
  if (!p) return {};
  return buildMetadata({ path: `/work/${p.slug}`, title: p.seoTitle || p.name, description: p.seoDescription || p.shortDescription, image: p.thumbnail });
}

export default async function ProjectDetail({ params }: Props) {
  const { slug } = await params;
  const p = await getProject(slug);
  if (!p) notFound();
  return (
    <>
      <div className="container-x pt-10">
        <Link href="/work" className="inline-flex items-center gap-1.5 text-sm text-ink/65 hover:text-brand"><ArrowLeft className="h-4 w-4" /> All work</Link>
      </div>
      <PageHero eyebrow={p.category} title={p.name} text={p.shortDescription} />
      {p.thumbnail && (
        <div className="container-x pb-12">
          <div className="relative aspect-[16/9] overflow-hidden rounded-3xl bg-mist"><Img src={p.thumbnail} alt={`${p.name} preview`} priority sizes="(min-width:1152px) 1100px, 100vw" /></div>
        </div>
      )}
      <section className="container-x grid gap-12 pb-12 lg:grid-cols-3">
        <div className="lg:col-span-2"><RichText text={p.detailedDescription} /></div>
        <aside className="h-fit space-y-6 rounded-3xl bg-mist p-8 text-sm">
          {p.completionDate && <div><p className="text-ink/55">Completed</p><p className="mt-1 font-medium">{fmtDate(p.completionDate)}</p></div>}
          {p.technologies.length > 0 && (
            <div>
              <p className="text-ink/55">Technologies</p>
              <ul className="mt-2 flex flex-wrap gap-2">{p.technologies.map((t) => <li key={t} className="rounded-full bg-white px-3 py-1 text-xs">{t}</li>)}</ul>
            </div>
          )}
          <div className="flex flex-col gap-2">
            {p.projectUrl && <a href={safeHref(p.projectUrl)} target="_blank" rel="noopener noreferrer" className="btn-primary btn-sm"><ExternalLink className="h-4 w-4" /> Visit project</a>}
            {p.githubUrl && <a href={safeHref(p.githubUrl)} target="_blank" rel="noopener noreferrer" className="btn-secondary btn-sm bg-white"><Github className="h-4 w-4" /> View on GitHub</a>}
          </div>
        </aside>
      </section>
      {p.images.length > 0 && (
        <section className="container-x pb-16" aria-label="Project gallery">
          <div className="grid gap-5 sm:grid-cols-2">
            {p.images.map((src, i) => (
              <div key={src + i} className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-mist"><Img src={src} alt={`${p.name} screenshot ${i + 1}`} /></div>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
