import { getServices } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { EmptyState, PageHero, ServiceCard } from "@/components/public/Cards";

export async function generateMetadata() {
  return buildMetadata({ path: "/services", title: "Services", description: "Web, software, AI, mobile, e-commerce and digital solutions from SHOMIQ TECHNOLOGIES." });
}

export default async function ServicesPage() {
  const services = await getServices();
  return (
    <>
      <PageHero eyebrow="Services" title="What we do." text="Technology services designed around your goals." />
      <section className="bg-mist py-16">
        <div className="container-x">
          {services.length === 0 ? (
            <EmptyState title="No services yet" text="Published services will appear here." />
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{services.map((s) => <ServiceCard key={s.id} s={s} />)}</div>
          )}
        </div>
      </section>
    </>
  );
}
