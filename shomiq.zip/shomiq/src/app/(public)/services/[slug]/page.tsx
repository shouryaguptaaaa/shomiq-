import Link from "next/link";
import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { getService, getSettings } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { siteUrl } from "@/lib/utils";
import { PageHero } from "@/components/public/Cards";
import { RichText } from "@/components/ui/RichText";
import { Img } from "@/components/ui/Img";
import { JsonLd } from "@/components/ui/JsonLd";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const s = await getService(slug);
  if (!s) return {};
  return buildMetadata({ path: `/services/${s.slug}`, title: s.seoTitle || s.name, description: s.seoDescription || s.shortDescription, image: s.coverImage });
}

export default async function ServiceDetail({ params }: Props) {
  const { slug } = await params;
  const [s, settings] = await Promise.all([getService(slug), getSettings()]);
  if (!s) notFound();
  return (
    <>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "Service", name: s.name, description: s.shortDescription, url: `${siteUrl()}/services/${s.slug}`, provider: { "@type": "Organization", name: settings["company.name"] } }} />
      <PageHero eyebrow="Service" title={s.name} text={s.shortDescription} />
      {s.coverImage && (
        <div className="container-x pb-12">
          <div className="relative aspect-[16/8] overflow-hidden rounded-3xl bg-mist"><Img src={s.coverImage} alt={`${s.name} cover`} priority sizes="(min-width:1152px) 1100px, 100vw" /></div>
        </div>
      )}
      <section className="container-x grid gap-12 pb-16 lg:grid-cols-3">
        <div className="lg:col-span-2"><RichText text={s.fullDescription} /></div>
        {s.features.length > 0 && (
          <aside className="h-fit rounded-3xl bg-mist p-8">
            <h2 className="text-lg font-semibold">Highlights</h2>
            <ul className="mt-5 space-y-3">
              {s.features.map((f) => (
                <li key={f} className="flex gap-3 text-[15px] text-ink/80"><Check className="mt-0.5 h-5 w-5 shrink-0 text-brand" aria-hidden />{f}</li>
              ))}
            </ul>
            <Link href={`/contact?subject=${encodeURIComponent(`Enquiry: ${s.name}`)}`} className="btn-primary mt-8 w-full">Discuss this service</Link>
          </aside>
        )}
      </section>
    </>
  );
}
