import { notFound } from "next/navigation";
import { getPage } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/public/Cards";
import { RichText } from "@/components/ui/RichText";

export async function generateMetadata() {
  const p = await getPage("terms");
  return buildMetadata({ path: "/terms", title: p?.seoTitle || p?.title, description: p?.seoDescription });
}

export default async function LegalPage() {
  const page = await getPage("terms");
  if (!page) notFound();
  return (
    <>
      <PageHero title={page.title} />
      <section className="container-x pb-16"><div className="max-w-3xl"><RichText text={page.content} /></div></section>
    </>
  );
}
