import { Mail, MapPin, Phone } from "lucide-react";
import { getSettings } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { PageHero } from "@/components/public/Cards";
import { ContactForm } from "@/components/public/ContactForm";

export async function generateMetadata() {
  return buildMetadata({ path: "/contact", title: "Contact Us", description: "Have an idea? Get in touch with SHOMIQ TECHNOLOGIES." });
}

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ subject?: string }> }) {
  const [{ subject }, s] = await Promise.all([searchParams, getSettings()]);
  const details = [
    { Icon: Mail, v: s["company.email"], href: `mailto:${s["company.email"]}` },
    { Icon: Phone, v: s["company.phone"], href: `tel:${s["company.phone"].replace(/\s/g, "")}` },
    { Icon: MapPin, v: s["company.address"] },
  ].filter((d) => d.v);
  return (
    <>
      <PageHero eyebrow="Contact" title="Let's talk." text="Tell us about your idea and we'll get back to you." />
      <section className="container-x grid gap-14 pb-16 lg:grid-cols-5">
        <div className="lg:col-span-2">
          {details.length > 0 ? (
            <ul className="space-y-5">
              {details.map(({ Icon, v, href }) => (
                <li key={v} className="flex gap-4">
                  <span className="rounded-full bg-mist p-3"><Icon className="h-5 w-5 text-brand" aria-hidden /></span>
                  <span className="self-center whitespace-pre-line text-ink/80">{href ? <a href={href} className="hover:text-brand">{v}</a> : v}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-ink/65">Use the form and our team will respond as soon as possible.</p>
          )}
        </div>
        <div className="card p-6 sm:p-8 lg:col-span-3">
          <ContactForm defaultSubject={(subject ?? "").slice(0, 150)} />
        </div>
      </section>
    </>
  );
}
