import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getFeaturedProjects, getServices, getSettings, getTeam } from "@/services/content";
import { buildMetadata } from "@/lib/seo";
import { parsePairs, safeHref, siteUrl } from "@/lib/utils";
import { Reveal } from "@/components/public/Reveal";
import { HeroVisual } from "@/components/public/HeroVisual";
import { EmptyState, ProjectCard, ServiceCard, TeamCard } from "@/components/public/Cards";
import { Img } from "@/components/ui/Img";
import { JsonLd } from "@/components/ui/JsonLd";

export async function generateMetadata() {
  return buildMetadata({ path: "/" });
}

export default async function HomePage() {
  const [s, services, projects, team] = await Promise.all([getSettings(), getServices(6), getFeaturedProjects(3), getTeam()]);
  const why = parsePairs(s["home.whyItems"]);
  const sameAs = ["linkedin", "twitter", "github", "instagram"].map((k) => s[`social.${k}`]).filter(Boolean);

  return (
    <>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Organization",
          name: s["company.name"],
          url: siteUrl(),
          slogan: s["company.tagline"],
          founder: team.filter((t) => /founder/i.test(t.designation)).map((t) => ({ "@type": "Person", name: t.fullName })),
          ...(sameAs.length ? { sameAs } : {}),
        }}
      />

      {/* Hero */}
      <section className="pt-14 sm:pt-24">
        <div className="container-x text-center">
          <h1 className="mx-auto max-w-4xl text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">{s["home.heroTitle"]}</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-ink/70 sm:text-xl">{s["home.heroSubtitle"]}</p>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link href={safeHref(s["home.heroPrimaryHref"])} className="btn-primary w-full sm:w-auto">{s["home.heroPrimaryLabel"]}</Link>
            <Link href={safeHref(s["home.heroSecondaryHref"])} className="btn-secondary w-full sm:w-auto">{s["home.heroSecondaryLabel"]}</Link>
          </div>
        </div>
        <div className="container-x mt-14 sm:mt-20">
          {s["home.heroImage"] ? (
            <div className="relative aspect-[16/8] overflow-hidden rounded-3xl bg-mist">
              <Img src={s["home.heroImage"]} alt={`${s["company.name"]} banner`} priority sizes="(min-width:1152px) 1100px, 100vw" />
            </div>
          ) : (
            <HeroVisual />
          )}
        </div>
      </section>

      {/* Introduction */}
      <section className="container-x py-24 sm:py-32">
        <Reveal className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.introTitle"]}</h2>
          <p className="mt-6 text-lg leading-relaxed text-ink/70 sm:text-xl">{s["home.introText"]}</p>
          <Link href="/about" className="mt-8 inline-flex items-center gap-1.5 font-medium text-brand hover:underline">About us <ArrowRight className="h-4 w-4" /></Link>
        </Reveal>
      </section>

      {/* Services */}
      <section className="bg-mist py-24 sm:py-28" aria-labelledby="services-h">
        <div className="container-x">
          <Reveal>
            <h2 id="services-h" className="text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.servicesTitle"]}</h2>
            <p className="mt-4 max-w-2xl text-lg text-ink/70">{s["home.servicesSubtitle"]}</p>
          </Reveal>
          {services.length === 0 ? (
            <div className="mt-12"><EmptyState title="Services coming soon" text="Published services will appear here." /></div>
          ) : (
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((sv, i) => <Reveal key={sv.id} delay={i * 0.05}><ServiceCard s={sv} /></Reveal>)}
            </div>
          )}
          <Link href="/services" className="mt-10 inline-flex items-center gap-1.5 font-medium text-brand hover:underline">All services <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>

      {/* Featured projects */}
      <section className="container-x py-24 sm:py-28" aria-labelledby="projects-h">
        <Reveal>
          <h2 id="projects-h" className="text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.projectsTitle"]}</h2>
          <p className="mt-4 max-w-2xl text-lg text-ink/70">{s["home.projectsSubtitle"]}</p>
        </Reveal>
        {projects.length === 0 ? (
          <div className="mt-12"><EmptyState title="Projects coming soon" text="Featured projects will appear here once they are published." /></div>
        ) : (
          <div className="mt-12 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p, i) => <Reveal key={p.id} delay={i * 0.05}><ProjectCard p={p} /></Reveal>)}
          </div>
        )}
        <Link href="/work" className="mt-12 inline-flex items-center gap-1.5 font-medium text-brand hover:underline">View all work <ArrowRight className="h-4 w-4" /></Link>
      </section>

      {/* Why choose us */}
      {why.length > 0 && (
        <section className="bg-mist py-24 sm:py-28" aria-labelledby="why-h">
          <div className="container-x">
            <Reveal><h2 id="why-h" className="text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.whyTitle"]}</h2></Reveal>
            <div className="mt-12 grid gap-10 md:grid-cols-3">
              {why.map((w, i) => (
                <Reveal key={w.a} delay={i * 0.05}>
                  <div className="border-t border-ink/15 pt-6">
                    <h3 className="text-xl font-semibold tracking-tight">{w.a}</h3>
                    <p className="mt-3 leading-relaxed text-ink/65">{w.b}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Leadership */}
      <section className="container-x py-24 sm:py-28" aria-labelledby="lead-h">
        <Reveal><h2 id="lead-h" className="text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.leadershipTitle"]}</h2></Reveal>
        {team.length === 0 ? (
          <div className="mt-12"><EmptyState title="Team coming soon" text="Team profiles will appear here." /></div>
        ) : (
          <div className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {team.map((m, i) => <Reveal key={m.id} delay={i * 0.05}><TeamCard m={m} /></Reveal>)}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="container-x pb-8">
        <Reveal className="rounded-[2rem] bg-mist px-6 py-16 text-center sm:py-24">
          <h2 className="mx-auto max-w-3xl text-3xl font-semibold tracking-tight sm:text-5xl">{s["home.ctaTitle"]}</h2>
          <Link href={safeHref(s["home.ctaHref"])} className="btn-primary mt-9">{s["home.ctaLabel"]}</Link>
        </Reveal>
      </section>
    </>
  );
}
