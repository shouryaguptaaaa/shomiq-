import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "SHOMIQ TECHNOLOGIES | Technology. Designed for What's Next.", template: "%s | SHOMIQ TECHNOLOGIES" },
  description: "SHOMIQ TECHNOLOGIES transforms ideas into meaningful digital experiences through technology, innovation and intelligent solutions.",
  openGraph: { siteName: "SHOMIQ TECHNOLOGIES", type: "website", locale: "en_US" },
};

export const viewport: Viewport = { themeColor: "#FFFFFF", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
