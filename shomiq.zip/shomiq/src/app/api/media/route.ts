import { NextResponse } from "next/server";
import { getAdminOrNull } from "@/lib/admin";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await getAdminOrNull())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await prisma.media.findMany({ orderBy: { createdAt: "desc" }, take: 80, select: { id: true, url: true, alt: true } });
  return NextResponse.json({ items });
}
