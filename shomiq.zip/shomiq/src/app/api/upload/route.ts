import { NextResponse } from "next/server";
import { getAdminOrNull } from "@/lib/admin";
import { cloudinary, cloudinaryReady } from "@/lib/cloudinary";
import { prisma } from "@/lib/db";
import { rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

const MAX_BYTES = 4 * 1024 * 1024; // Vercel serverless request limit is ~4.5MB

function sniff(b: Buffer): string | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP") return "image/webp";
  if (b.subarray(0, 3).toString() === "GIF") return "image/gif";
  if (b.subarray(4, 12).toString().startsWith("ftypavif")) return "image/avif";
  return null;
}

export async function POST(req: Request) {
  const admin = await getAdminOrNull();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!rateLimit(`upload:${admin.id}`, 40, 60_000).ok) return NextResponse.json({ error: "Too many uploads. Slow down." }, { status: 429 });
  if (!cloudinaryReady()) return NextResponse.json({ error: "Cloudinary is not configured. Add the CLOUDINARY_* variables to .env." }, { status: 500 });

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "No file provided." }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "Image must be 4 MB or smaller." }, { status: 413 });

  const buf = Buffer.from(await file.arrayBuffer());
  if (!sniff(buf)) return NextResponse.json({ error: "Only JPEG, PNG, WebP, GIF or AVIF images are allowed." }, { status: 415 });

  try {
    const res = await new Promise<{ secure_url: string; public_id: string; width: number; height: number; format: string; bytes: number }>((resolve, reject) => {
      cloudinary.uploader
        .upload_stream({ folder: "shomiq", resource_type: "image" }, (err, r) => (err || !r ? reject(err) : resolve(r as never)))
        .end(buf);
    });
    const media = await prisma.media.create({
      data: { url: res.secure_url, publicId: res.public_id, width: res.width, height: res.height, format: res.format, bytes: res.bytes, uploadedById: admin.id },
    });
    return NextResponse.json({ id: media.id, url: media.url });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Upload failed. Please try again." }, { status: 500 });
  }
}
