import { AdminHeader } from "@/components/admin/bits";
import { ServiceForm } from "@/components/admin/Forms";

export default function NewService() {
  return (<><AdminHeader title="New service" /><ServiceForm /></>);
}
