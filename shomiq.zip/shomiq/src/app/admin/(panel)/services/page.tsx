import Link from "next/link";
import { prisma } from "@/lib/db";
import { deleteService } from "@/actions/services";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";
import { ConfirmButton } from "@/components/ui/ConfirmButton";

export default async function ServicesAdmin() {
  const items = await prisma.service.findMany({ orderBy: [{ displayOrder: "asc" }, { name: "asc" }] });
  return (
    <>
      <AdminHeader title="Services" newHref="/admin/services/new" newLabel="New service" />
      {items.length === 0 ? <Empty text="No services yet." /> : (
        <ul className="card divide-y divide-black/5">
          {items.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0"><p className="font-medium">{s.name}</p><p className="text-xs text-ink/55">/{s.slug} · order {s.displayOrder}</p></div>
              <div className="flex items-center gap-2"><Badge value={s.status} /><Link href={`/admin/services/${s.id}`} className="btn-secondary btn-sm">Edit</Link><ConfirmButton action={deleteService.bind(null, s.id)} message={`Delete “${s.name}”? This cannot be undone.`}>Delete</ConfirmButton></div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
