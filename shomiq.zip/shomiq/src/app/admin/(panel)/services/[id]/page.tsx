import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AdminHeader } from "@/components/admin/bits";
import { ServiceForm } from "@/components/admin/Forms";

export default async function EditService({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const service = await prisma.service.findUnique({ where: { id } });
  if (!service) notFound();
  return (<><AdminHeader title={`Edit: ${service.name}`} /><ServiceForm service={service} /></>);
}
