import { AdminHeader } from "@/components/admin/bits";
import { SettingsForm } from "@/components/admin/SettingsForm";

export default function HomepageAdmin() {
  return (<><AdminHeader title="Homepage content" text="Edit headings, banner, buttons and call-to-action." /><div className="max-w-3xl"><SettingsForm groupIds={["home"]} /></div></>);
}
