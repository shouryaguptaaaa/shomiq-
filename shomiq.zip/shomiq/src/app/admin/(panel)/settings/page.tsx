import { AdminHeader } from "@/components/admin/bits";
import { SettingsForm } from "@/components/admin/SettingsForm";

export default function SettingsAdmin() {
  return (<><AdminHeader title="Website settings" text="Company details, navigation, footer and social links." /><div className="max-w-3xl"><SettingsForm groupIds={["company", "nav", "footer", "social"]} /></div></>);
}
