import { AdminHeader } from "@/components/admin/bits";
import { TeamForm } from "@/components/admin/Forms";

export default function NewMember() {
  return (<><AdminHeader title="Add team member" /><TeamForm /></>);
}
