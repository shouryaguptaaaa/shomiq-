import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AdminHeader } from "@/components/admin/bits";
import { TeamForm } from "@/components/admin/Forms";

export default async function EditMember({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const member = await prisma.teamMember.findUnique({ where: { id } });
  if (!member) notFound();
  return (<><AdminHeader title={`Edit: ${member.fullName}`} /><TeamForm member={member} /></>);
}
