import Link from "next/link";
import { prisma } from "@/lib/db";
import { deleteTeamMember } from "@/actions/team";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";
import { ConfirmButton } from "@/components/ui/ConfirmButton";

export default async function TeamAdmin() {
  const items = await prisma.teamMember.findMany({ orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }] });
  return (
    <>
      <AdminHeader title="Team" newHref="/admin/team/new" newLabel="Add member" />
      {items.length === 0 ? <Empty text="No team members yet." /> : (
        <ul className="card divide-y divide-black/5">
          {items.map((m) => (
            <li key={m.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0"><p className="font-medium">{m.fullName}</p><p className="text-xs text-ink/55">{m.designation} · order {m.displayOrder}</p></div>
              <div className="flex items-center gap-2"><Badge value={m.status} /><Link href={`/admin/team/${m.id}`} className="btn-secondary btn-sm">Edit</Link><ConfirmButton action={deleteTeamMember.bind(null, m.id)} message={`Remove ${m.fullName}?`}>Delete</ConfirmButton></div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
