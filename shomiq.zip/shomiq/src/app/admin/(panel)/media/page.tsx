import { prisma } from "@/lib/db";
import { cloudinaryReady } from "@/lib/cloudinary";
import { deleteMedia } from "@/actions/media";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { ConfirmButton } from "@/components/ui/ConfirmButton";
import { CopyButton, UploadButton } from "@/components/admin/MediaTools";

export default async function MediaAdmin() {
  const items = await prisma.media.findMany({ orderBy: { createdAt: "desc" }, take: 120 });
  return (
    <>
      <AdminHeader title="Media library" text="Images up to 4 MB (JPEG, PNG, WebP, GIF, AVIF)." />
      {!cloudinaryReady() && <p className="mb-6 rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800">Cloudinary is not configured yet. Add the CLOUDINARY_* variables to your environment to enable uploads.</p>}
      <div className="mb-6"><UploadButton /></div>
      {items.length === 0 ? <Empty text="No images uploaded yet." /> : (
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((m) => (
            <li key={m.id} className="card overflow-hidden">
              <div className="aspect-square bg-mist">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={m.url} alt={m.alt ?? ""} loading="lazy" className="h-full w-full object-cover" /></div>
              <div className="space-y-2 p-3">
                <p className="truncate text-xs text-ink/55">{m.width}×{m.height} · {m.format}</p>
                <div className="flex flex-wrap gap-2"><CopyButton text={m.url} /><ConfirmButton action={deleteMedia.bind(null, m.id)} message="Delete this image? Pages that use it will show a placeholder.">Delete</ConfirmButton></div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
