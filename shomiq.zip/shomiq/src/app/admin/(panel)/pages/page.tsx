import Link from "next/link";
import { prisma } from "@/lib/db";
import { fmtDateTime } from "@/lib/utils";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";

export default async function PagesAdmin() {
  const pages = await prisma.page.findMany({ orderBy: { title: "asc" } });
  return (
    <>
      <AdminHeader title="Pages" text="About, Privacy Policy and Terms content." />
      {pages.length === 0 ? <Empty text="No pages found. Run the seed script." /> : (
        <ul className="card divide-y divide-black/5">
          {pages.map((p) => (
            <li key={p.id} className="flex items-center justify-between gap-3 p-4">
              <div><p className="font-medium">{p.title}</p><p className="text-xs text-ink/55">/{p.slug} · updated {fmtDateTime(p.updatedAt)}</p></div>
              <div className="flex items-center gap-3"><Badge value={p.status} /><Link href={`/admin/pages/${p.id}`} className="btn-secondary btn-sm">Edit</Link></div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
