import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AdminHeader } from "@/components/admin/bits";
import { PageForm } from "@/components/admin/Forms";

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const page = await prisma.page.findUnique({ where: { id } });
  if (!page) notFound();
  return (<><AdminHeader title={`Edit: ${page.title}`} /><PageForm page={page} /></>);
}
