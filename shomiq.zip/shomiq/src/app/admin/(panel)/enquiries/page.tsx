import Link from "next/link";
import type { EnquiryStatus, Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { fmtDateTime, cn } from "@/lib/utils";
import { deleteEnquiry, setEnquiryStatus } from "@/actions/enquiries";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";
import { ConfirmButton } from "@/components/ui/ConfirmButton";

const STATUSES: EnquiryStatus[] = ["NEW", "IN_PROGRESS", "RESOLVED"];

export default async function EnquiriesAdmin({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  const { q = "", status = "" } = await searchParams;
  const query = q.trim().slice(0, 100);
  const where: Prisma.EnquiryWhereInput = {
    ...(STATUSES.includes(status as EnquiryStatus) ? { status: status as EnquiryStatus } : {}),
    ...(query ? { OR: ["name", "email", "subject", "message", "company"].map((f) => ({ [f]: { contains: query, mode: "insensitive" } })) as Prisma.EnquiryWhereInput[] } : {}),
  };
  const items = await prisma.enquiry.findMany({ where, orderBy: { createdAt: "desc" }, take: 100 });
  const tab = (active: boolean) => cn("rounded-full px-4 py-1.5 text-sm", active ? "bg-ink text-white" : "bg-white text-ink/70");
  const qs = (s: string) => `/admin/enquiries?${new URLSearchParams({ ...(query ? { q: query } : {}), ...(s ? { status: s } : {}) })}`;

  return (
    <>
      <AdminHeader title="Contact enquiries" />
      <form className="mb-4 flex gap-2" action="/admin/enquiries">
        {status && <input type="hidden" name="status" value={status} />}
        <input name="q" defaultValue={query} placeholder="Search name, email, subject, message…" className="input max-w-md" aria-label="Search enquiries" />
        <button className="btn-primary btn-sm">Search</button>
      </form>
      <nav className="mb-6 flex flex-wrap gap-2" aria-label="Filter by status">
        <Link href={qs("")} className={tab(!status)}>All</Link>
        {STATUSES.map((s) => <Link key={s} href={qs(s)} className={tab(status === s)}>{s.replace("_", " ").toLowerCase()}</Link>)}
      </nav>
      {items.length === 0 ? <Empty text="No enquiries found." /> : (
        <ul className="space-y-3">
          {items.map((e) => (
            <li key={e.id} className="card">
              <details className="group">
                <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-3 p-4">
                  <div className="min-w-0"><p className="truncate font-medium">{e.subject}</p><p className="truncate text-sm text-ink/60">{e.name} · {e.email} · {fmtDateTime(e.createdAt)}</p></div>
                  <Badge value={e.status} />
                </summary>
                <div className="space-y-4 border-t border-black/5 p-4">
                  <dl className="grid gap-2 text-sm sm:grid-cols-2">
                    <div><dt className="text-ink/55">Email</dt><dd><a className="text-brand" href={`mailto:${e.email}`}>{e.email}</a></dd></div>
                    {e.phone && <div><dt className="text-ink/55">Phone</dt><dd>{e.phone}</dd></div>}
                    {e.company && <div><dt className="text-ink/55">Company</dt><dd>{e.company}</dd></div>}
                    <div><dt className="text-ink/55">Received</dt><dd>{fmtDateTime(e.createdAt)}</dd></div>
                  </dl>
                  <p className="whitespace-pre-wrap rounded-xl bg-mist p-4 text-sm leading-relaxed">{e.message}</p>
                  <div className="flex flex-wrap gap-2">
                    {STATUSES.filter((s) => s !== e.status).map((s) => (
                      <ConfirmButton key={s} action={setEnquiryStatus.bind(null, e.id, s)} message={`Mark as ${s.replace("_", " ").toLowerCase()}?`} className="btn-secondary btn-sm">Mark {s.replace("_", " ").toLowerCase()}</ConfirmButton>
                    ))}
                    <ConfirmButton action={deleteEnquiry.bind(null, e.id)} message="Delete this enquiry permanently?">Delete</ConfirmButton>
                  </div>
                </div>
              </details>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
