import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/admin";
import { fmtDateTime } from "@/lib/utils";
import { revokeOtherSessions, revokeSession } from "@/actions/account";
import { AdminHeader, Empty, Panel } from "@/components/admin/bits";
import { ConfirmButton } from "@/components/ui/ConfirmButton";

export default async function SecurityAdmin() {
  const me = await requireAdmin();
  const [sessions, logins] = await Promise.all([
    prisma.adminSession.findMany({ where: { userId: me.id, revokedAt: null, expiresAt: { gt: new Date() } }, orderBy: { createdAt: "desc" } }),
    prisma.activityLog.findMany({ where: { userId: me.id, action: "login" }, orderBy: { createdAt: "desc" }, take: 10 }),
  ]);
  return (
    <>
      <AdminHeader title="Security & sessions" text="Active sign-ins for your account." />
      <div className="max-w-3xl space-y-6">
        <Panel>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold">Active sessions</h2>
            {sessions.length > 1 && <ConfirmButton action={revokeOtherSessions} message="Sign out all other sessions?">Sign out other sessions</ConfirmButton>}
          </div>
          {sessions.length === 0 ? <Empty text="No active sessions." /> : (
            <ul className="divide-y divide-black/5">
              {sessions.map((s) => (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div className="min-w-0 text-sm">
                    <p className="font-medium">{s.id === me.sid ? "This session" : "Other session"}</p>
                    <p className="truncate text-ink/60">{s.ip ?? "Unknown IP"} · {s.userAgent ?? "Unknown device"}</p>
                    <p className="text-xs text-ink/55">Started {fmtDateTime(s.createdAt)} · expires {fmtDateTime(s.expiresAt)}</p>
                  </div>
                  {s.id !== me.sid && <ConfirmButton action={revokeSession.bind(null, s.id)} message="Sign out this session?">Revoke</ConfirmButton>}
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel>
          <h2 className="mb-4 text-lg font-semibold">Recent sign-ins</h2>
          {logins.length === 0 ? <Empty text="No sign-ins recorded." /> : <ul className="space-y-2 text-sm">{logins.map((l) => <li key={l.id}>{fmtDateTime(l.createdAt)}</li>)}</ul>}
        </Panel>
      </div>
    </>
  );
}
