import { AdminHeader } from "@/components/admin/bits";
import { ProjectForm } from "@/components/admin/Forms";

export default function NewProject() {
  return (<><AdminHeader title="New project" /><ProjectForm /></>);
}
