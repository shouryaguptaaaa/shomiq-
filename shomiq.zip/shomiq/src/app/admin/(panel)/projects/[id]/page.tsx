import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AdminHeader } from "@/components/admin/bits";
import { ProjectForm } from "@/components/admin/Forms";

export default async function EditProject({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await prisma.project.findUnique({ where: { id } });
  if (!project) notFound();
  return (<><AdminHeader title={`Edit: ${project.name}`} /><ProjectForm project={project} /></>);
}
