import Link from "next/link";
import { prisma } from "@/lib/db";
import { deleteProject } from "@/actions/projects";
import { AdminHeader, Empty } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";
import { ConfirmButton } from "@/components/ui/ConfirmButton";

export default async function ProjectsAdmin() {
  const items = await prisma.project.findMany({ orderBy: { updatedAt: "desc" } });
  return (
    <>
      <AdminHeader title="Projects" newHref="/admin/projects/new" newLabel="New project" />
      {items.length === 0 ? <Empty text="No projects yet. Add your first one." /> : (
        <ul className="card divide-y divide-black/5">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0"><p className="font-medium">{p.name}{p.featured && <span className="ml-2 text-xs text-brand">★ featured</span>}</p><p className="text-xs text-ink/55">{p.category} · /{p.slug}</p></div>
              <div className="flex items-center gap-2"><Badge value={p.status} /><Link href={`/admin/projects/${p.id}`} className="btn-secondary btn-sm">Edit</Link><ConfirmButton action={deleteProject.bind(null, p.id)} message={`Delete “${p.name}”? This cannot be undone.`}>Delete</ConfirmButton></div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
