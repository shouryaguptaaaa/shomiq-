import Link from "next/link";
import { prisma } from "@/lib/db";
import { fmtDateTime } from "@/lib/utils";
import { AdminHeader, Empty, Panel } from "@/components/admin/bits";
import { Badge } from "@/components/ui/fields";

export default async function Dashboard() {
  const [projects, services, enquiries, newEnquiries, recent, activity] = await Promise.all([
    prisma.project.count(),
    prisma.service.count(),
    prisma.enquiry.count(),
    prisma.enquiry.count({ where: { status: "NEW" } }),
    prisma.enquiry.findMany({ orderBy: { createdAt: "desc" }, take: 5 }),
    prisma.activityLog.findMany({ orderBy: { createdAt: "desc" }, take: 8, include: { user: { select: { name: true } } } }),
  ]);
  const stats = [
    { label: "Projects", value: projects, href: "/admin/projects" },
    { label: "Services", value: services, href: "/admin/services" },
    { label: "Total enquiries", value: enquiries, href: "/admin/enquiries" },
    { label: "New enquiries", value: newEnquiries, href: "/admin/enquiries?status=NEW" },
  ];
  return (
    <>
      <AdminHeader title="Dashboard" text="Live data from your database." />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Link key={s.label} href={s.href} className="card p-5 transition-shadow hover:shadow-md">
            <p className="text-sm text-ink/60">{s.label}</p>
            <p className="mt-2 text-3xl font-semibold tracking-tight">{s.value}</p>
          </Link>
        ))}
      </div>
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Panel>
          <h2 className="mb-4 text-lg font-semibold">Recent enquiries</h2>
          {recent.length === 0 ? <Empty text="No enquiries yet." /> : (
            <ul className="divide-y divide-black/5">
              {recent.map((e) => (
                <li key={e.id} className="flex items-start justify-between gap-3 py-3">
                  <div className="min-w-0"><p className="truncate font-medium">{e.subject}</p><p className="truncate text-sm text-ink/60">{e.name} · {fmtDateTime(e.createdAt)}</p></div>
                  <Badge value={e.status} />
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel>
          <h2 className="mb-4 text-lg font-semibold">Recent activity</h2>
          {activity.length === 0 ? <Empty text="No activity yet." /> : (
            <ul className="divide-y divide-black/5">
              {activity.map((a) => (
                <li key={a.id} className="py-3 text-sm">
                  <p><span className="font-medium">{a.user?.name ?? "System"}</span> {a.action} {a.entity.toLowerCase()}{a.details ? ` “${a.details}”` : ""}</p>
                  <p className="text-xs text-ink/55">{fmtDateTime(a.createdAt)}</p>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  );
}
