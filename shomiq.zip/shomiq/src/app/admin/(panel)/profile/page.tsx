import { requireAdmin } from "@/lib/admin";
import { changePassword, updateProfile } from "@/actions/account";
import { AdminHeader, Panel } from "@/components/admin/bits";
import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input } from "@/components/ui/fields";

export default async function ProfileAdmin() {
  const me = await requireAdmin();
  return (
    <>
      <AdminHeader title="Admin profile" />
      <div className="max-w-xl space-y-6">
        <Panel>
          <h2 className="mb-4 text-lg font-semibold">Details</h2>
          <ActionForm action={updateProfile} className="space-y-4">
            <Field label="Name"><Input name="name" required defaultValue={me.name} maxLength={100} /></Field>
            <Field label="Email"><Input name="email" type="email" required defaultValue={me.email} maxLength={200} /></Field>
          </ActionForm>
        </Panel>
        <Panel>
          <h2 className="mb-4 text-lg font-semibold">Change password</h2>
          <ActionForm action={changePassword} submitLabel="Change password" resetOnSuccess className="space-y-4">
            <Field label="Current password"><Input name="current" type="password" required autoComplete="current-password" /></Field>
            <Field label="New password" help="At least 12 characters, with letters and numbers."><Input name="next" type="password" required minLength={12} autoComplete="new-password" /></Field>
            <Field label="Confirm new password"><Input name="confirm" type="password" required autoComplete="new-password" /></Field>
          </ActionForm>
        </Panel>
      </div>
    </>
  );
}
