import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/admin";
import { logoutAction } from "@/actions/auth";
import { AdminShell } from "@/components/admin/AdminShell";

export default async function PanelLayout({ children }: { children: ReactNode }) {
  const user = await requireAdmin();
  return <AdminShell user={{ name: user.name, email: user.email }} logout={logoutAction}>{children}</AdminShell>;
}
