export default function Loading() {
  return <div role="status" aria-label="Loading" className="space-y-4"><div className="h-8 w-1/3 animate-pulse rounded-xl bg-white" /><div className="h-40 animate-pulse rounded-2xl bg-white" /></div>;
}
