import { prisma } from "@/lib/db";
import { SEO_PATHS } from "@/validations";
import { saveSeo } from "@/actions/content";
import { AdminHeader, Panel } from "@/components/admin/bits";
import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input, Textarea } from "@/components/ui/fields";
import { ImageField } from "@/components/admin/ImageField";

export default async function SeoAdmin() {
  const rows = await prisma.seoMetadata.findMany();
  const byPath = new Map(rows.map((r) => [r.path, r]));
  return (
    <>
      <AdminHeader title="SEO management" text="Override title, description and social image per page. Services, projects and CMS pages also have their own SEO fields." />
      <div className="max-w-3xl space-y-6">
        {SEO_PATHS.map((path) => {
          const r = byPath.get(path);
          return (
            <Panel key={path}>
              <h2 className="mb-4 text-lg font-semibold">{path === "/" ? "Home (/)" : path}</h2>
              <ActionForm action={saveSeo} submitLabel="Save" className="space-y-4">
                <input type="hidden" name="path" value={path} />
                <Field label="Title"><Input name="title" defaultValue={r?.title ?? ""} maxLength={70} /></Field>
                <Field label="Description"><Textarea name="description" rows={2} defaultValue={r?.description ?? ""} maxLength={170} /></Field>
                <ImageField name="ogImage" label="Social share image" defaultValue={r?.ogImage} />
                <label className="flex items-center gap-3 text-sm"><input type="checkbox" name="noIndex" defaultChecked={r?.noIndex} className="h-4 w-4 accent-brand" />Hide from search engines (noindex)</label>
              </ActionForm>
            </Panel>
          );
        })}
      </div>
    </>
  );
}
