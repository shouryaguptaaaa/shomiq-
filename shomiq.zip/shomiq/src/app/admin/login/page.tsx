import { ActionForm } from "@/components/ui/ActionForm";
import { Field, Input } from "@/components/ui/fields";
import { LogoMark } from "@/components/ui/Logo";
import { loginAction } from "@/actions/auth";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-mist px-4">
      <div className="card w-full max-w-sm p-8">
        <div className="mb-6 flex flex-col items-center text-center">
          <LogoMark size={40} />
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">Admin sign in</h1>
          <p className="mt-1 text-sm text-ink/60">SHOMIQ TECHNOLOGIES</p>
        </div>
        <ActionForm action={loginAction} submitLabel="Sign in" className="space-y-4" buttonClassName="w-full">
          <Field label="Email"><Input name="email" type="email" required autoComplete="username" /></Field>
          <Field label="Password"><Input name="password" type="password" required autoComplete="current-password" /></Field>
        </ActionForm>
      </div>
    </div>
  );
}
