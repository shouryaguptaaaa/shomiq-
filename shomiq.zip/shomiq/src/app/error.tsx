"use client";

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container-x flex min-h-[60vh] flex-col items-center justify-center text-center">
      <h1 className="text-3xl font-semibold tracking-tight">Something went wrong</h1>
      <p className="mt-3 max-w-md text-ink/70">We hit an unexpected problem loading this page. Please try again.</p>
      <button onClick={reset} className="btn-primary mt-8">Try again</button>
    </div>
  );
}
