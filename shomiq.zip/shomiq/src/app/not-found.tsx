import Link from "next/link";
import { SiteHeader } from "@/components/public/SiteHeader";
import { SiteFooter } from "@/components/public/SiteFooter";

export default function NotFound() {
  return (
    <>
      <SiteHeader />
      <main className="container-x flex min-h-[60vh] flex-col items-center justify-center py-24 text-center">
        <p className="eyebrow">404</p>
        <h1 className="mt-3 text-4xl font-semibold tracking-tight sm:text-5xl">This page could not be found.</h1>
        <p className="mt-4 max-w-md text-ink/70">The page you are looking for may have moved or no longer exists.</p>
        <Link href="/" className="btn-primary mt-8">Back to home</Link>
      </main>
      <SiteFooter />
    </>
  );
}
