import { prisma } from "@/lib/db";

export async function logActivity(userId: string, action: string, entity: string, entityId?: string, details?: string) {
  try {
    await prisma.activityLog.create({ data: { userId, action, entity, entityId, details: details?.slice(0, 250) } });
  } catch (e) {
    console.error("activity log failed", e);
  }
}
