import { cache } from "react";
import { prisma } from "@/lib/db";
import { DEFAULTS } from "@/lib/settings-defs";

const pub = { status: "PUBLISHED" as const };

export const getSettings = cache(async () => {
  const m: Record<string, string> = { ...DEFAULTS };
  try {
    const rows = await prisma.siteSetting.findMany();
    for (const r of rows) m[r.key] = r.value;
  } catch (e) {
    console.error("Could not load settings, using defaults", e);
  }
  return m;
});

export const getServices = (take?: number) =>
  prisma.service.findMany({ where: pub, orderBy: [{ displayOrder: "asc" }, { name: "asc" }], take });

export const getService = (slug: string) => prisma.service.findFirst({ where: { slug, ...pub } });

export const getFeaturedProjects = (take = 3) =>
  prisma.project.findMany({ where: { ...pub, featured: true }, orderBy: { createdAt: "desc" }, take });

export const getProjects = (category?: string) =>
  prisma.project.findMany({
    where: { ...pub, ...(category ? { category } : {}) },
    orderBy: [{ completionDate: { sort: "desc", nulls: "last" } }, { createdAt: "desc" }],
  });

export const getProjectCategories = async () =>
  (await prisma.project.findMany({ where: pub, select: { category: true }, distinct: ["category"], orderBy: { category: "asc" } })).map((c) => c.category);

export const getProject = (slug: string) => prisma.project.findFirst({ where: { slug, ...pub } });

export const getTeam = () => prisma.teamMember.findMany({ where: pub, orderBy: [{ displayOrder: "asc" }, { createdAt: "asc" }] });

export const getPage = (slug: string) => prisma.page.findFirst({ where: { slug, ...pub } });
